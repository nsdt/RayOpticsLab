# Contribution verification, 12 November 2026

The canonical article remains ../manuscript/main.tex. Abstract, Discussion, and
Conclusion remain outside the draft scope. Archived engine and image data remain
unchanged. New calculations use CPU double precision.

Experiments: (1) locate U,D,L,R in both modes for reciprocal/quadratic g =
0,0.1,0.2,0.3,0.4 and heliconical omega = 0,1,2.5,4,6; measure normalized positions,
mode separation, and residual after best translation. (2) independently compare
interface directions and flux with admittance formulas, including reverse
incidence and total reflection; compare complete incoherent slab transport with
an infinite series; assess mode coupling with an independent rotating-axis Maxwell
calculation. (3) time identical camera samples with analytical propagation where
applicable versus forced RKF45; record actual calls, failures, and radiance differences.

Checklist: single TeX source; no new abstract/discussion/conclusion; definitions
before use; settings in Sec. 3; :=; lens terminology; formal declarative prose;
no inanimate agents for researchers' actions; precise referents; citations retained;
numerical agreement is not an error bound; conditional solutions distinguished;
each edited unit scientifically, mechanically and semantically reviewed before
the next; generator/Markdown synchronized; PDF and figures visually inspected.

Terminology: landmark position is continuous camera coordinate normalized by image
width. Mode separation is the distance between positions for one target landmark.
Translation residual is RMS displacement after subtracting the mean displacement.
Internal propagation evaluations include launch and exit refinement, but exclude
exterior intersection. They are not unique rays or RKF stages. Search failures are
recorded and do not establish nonexistence. Definitions precede settings and results.
