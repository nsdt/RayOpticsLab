# Additional experiments for the Applied Optics manuscript

12 November 2026. This archive contains the calculations added in Sections 2.7–2.8 and 3.9–3.12, including the data for Figures 18–19 and Tables 3–4. The original 75 monochromatic images and four spectral configurations were not recomputed in this revision. Their figures are supplied in the accompanying manuscript package; their original calculation archives remain separate.

## Reproduction

Use Python with the packages in requirements.txt and Node.js (the reported timings use 24.22.1). No npm packages are required. From this directory, run the following commands in order:

```sh
python -m pip install -r requirements.txt
python scripts/interface-cases.py
node scripts/interfaces.cjs
python scripts/maxwell-interfaces.py
node scripts/maxwell-interfaces.cjs
python scripts/maxwell-helix.py
node scripts/landmark-sweep.cjs
node scripts/timings.cjs
python scripts/figures.py
python scripts/validate-results.py
```

Each calculation replaces its named JSON output in data/. Retain a copy of the supplied data before rerunning if the original measurements are needed. Run the timing experiment without concurrent numerical workloads. Its warm-up and measurement loops are sequential. Wall-clock values depend on the CPU, runtime, and system load and are not expected to reproduce bit for bit. The reported times concern 144 camera directions, not complete rendered frames. This experiment measures CPU double-precision calculations, not GPU execution.

To inspect the supplied results without recomputation, run only validate-results.py. To regenerate the two added figures, run figures.py. A copy is also written to a sibling manuscript/figures directory if that directory exists. Otherwise, all figure outputs remain in figures/.

## Contents and provenance

- engine/: unchanged snapshot from experiments_20260927_revision/engine, retained to compare with the existing manuscript images.
- scripts/engine.cjs: unchanged diagnostic wrapper from the same archived experiment. It records ray states and path contributions. The independent Python reference calculations do not import renderer formulas.
- configs/manifest.json: unchanged 75-scene manifest from experiments_20260928_isotropic_columns/configs. The timing experiment selects its 15 representative configurations.
- data/: independent reference inputs, individual measured results, timing repetitions and counters, summary, and consistency-check report.
- figures/: the two added plots, in PDF and PNG.
- SHA256SUMS.json: hashes of the distributed files; provenance.json records the runtime and source snapshots.

The workspace also retains baseline manuscripts, authoring scripts, prose reviews, final diffs, and rendered PDF checks. Those authoring records are not required to reproduce the numerical calculations and are excluded from this numerical archive.

## Interpretation of the tests

The landmark experiment locates 120 selected direct connections: four marks, two modes, and five parameter values for each of three distributions. Positions are continuous camera coordinates. Search success does not prove uniqueness or exhaustiveness. The displacement residual is measured after subtracting the best common translation.

The planar interface checks comprise 80 decoupled admittance conditions (including reverse incidence and total internal reflection) and 96 independent Maxwell eigenproblem conditions with four incident polarization states. Twenty homogeneous slab conditions additionally test accumulated incoherent power against an infinite reflection series. These tests concern positive uniaxial dielectrics; they are not a validation of all indefinite or magnetic material models.

The rotating-axis Maxwell experiment uses homogeneous leads matched to the endpoint axes, one incident mode at the entrance, and no incoming mode at the far boundary. The transferred power is sampled within the slab, maximized over both incident modes, and normalized by incident power. Its dependence on physical length assesses the uncoupled-mode approximation for the specified normal-incidence configuration. It is not an error bound for complete images, oblique rays, other axis distributions, or near-degenerate modes.

The timing counters count internal propagation evaluations, including interior launch and boundary refinement. They do not count unique rays or Runge–Kutta stages. Homogeneous segments use the same straight-line procedure under both solver settings. Some representative configurations use RKF45 for every internal evaluation even when analytical propagation is enabled; no analytical speed benefit is claimed for those configurations.
