/* WebGPU host runs in the existing Worker. Pixels rejected by f32 guards are
 * recomputed from their original camera rays in the CPU double reference. */
(function(root){
'use strict';
const O=root.Optics,F=O.polarization,CAP=128,STRIDE=256,RAY_BYTES=80;
const reasons={1:'臨界角・根の精度',2:'接線・固有偏光',3:'界面行列・収支',4:'GPU待機領域の上限',5:'形状の稜線・交点',6:'背景境界の判定',7:'閉式軌道の条件外',8:'GPU結果の収支・有限値',9:'二軸の四次根・近接根',10:'二軸の固有偏光・縮退',11:'GRIN軌道・曲面交点・追跡上限',12:'GRIN偏光輸送',13:'異方不均一：構成式・伝播条件・分散残差',14:'前方2モード・流束規格化・縮退',15:'位相・分配積分の単精度精度／計算上限',16:'光束分離・内部評価面・表面の条件',17:'数値軌道・交点・単調z区間・追跡上限',18:'RKF45の誤差制御・刻み下限・試行回数上限',19:'出口の位置・方向の収束確認'};
// Retain the device and a bounded set of compiled variants in the GPU Worker.
// Every image still gets fresh uniforms, ray queues, output buffers and counters.
let cached=null;
function clearCache(){if(cached){const old=cached;cached=null;old.device.destroy();}}
async function runtime(build){
 if(cached&&(cached.build!==build||cached.fatal))clearCache();
 if(cached)return {state:cached,reused:true};
 const adapter=await navigator.gpu.requestAdapter({powerPreference:'high-performance'});
 if(!adapter)throw Error('WebGPUデバイスを取得できません。');
 const device=await adapter.requestDevice(),state={build,adapter,device,fatal:null,pipelines:new Map(),sources:null};
 cached=state;
 device.addEventListener('uncapturederror',e=>{state.fatal=e.error.message;});
 device.lost.then(info=>{state.fatal=info.message||'GPUデバイスが失われました';if(cached===state)cached=null;});
 state.layout=device.createBindGroupLayout({entries:[{binding:0,visibility:GPUShaderStage.COMPUTE,buffer:{type:'uniform'}},{binding:1,visibility:GPUShaderStage.COMPUTE,buffer:{type:'storage'}},{binding:2,visibility:GPUShaderStage.COMPUTE,buffer:{type:'storage'}}]});
 state.pipelineLayout=device.createPipelineLayout({bindGroupLayouts:[state.layout]});
 return {state,reused:false};
}
async function pipelines(state,c,branchKind,effectiveMaterial,timing){
 const key=JSON.stringify([c.material,effectiveMaterial,c.shape,c.solver,branchKind]),cache=state.pipelines;
 if(cache.has(key)){const hit=cache.get(key);cache.delete(key);cache.set(key,hit);timing.pipelineCacheHit=true;return hit;}
 timing.pipelineCacheHit=false;
 const loadStart=performance.now();
 if(!state.sources)state.sources=await Promise.all(['gpu-optics.wgsl','gpu-numerical.wgsl','gpu-phase.wgsl'].map(async name=>{const response=await fetch(name+'?v='+encodeURIComponent(state.build));if(!response.ok)throw Error('GPUシェーダを読み込めません: '+name);return response.text();}));
 timing.sourceLoadMs=performance.now()-loadStart;
 const compileStart=performance.now();
 let [base,numerical,phaseSource]=state.sources;
 if(branchKind===0)phaseSource='fn internalSplit(r:Ray,end:Path)->bool{return false;} fn coherentBulk(r:Ray){}';
 else if(branchKind!==3)phaseSource=phaseSource.slice(0,phaseSource.indexOf('fn helicalSeparation'))+'fn coherentBulk(r:Ray){}';
 const source=base.replace(/^\uFEFF/,'')+'\n'+numerical+'\n'+phaseSource;
 // These are all compile-time substitutions; other settings remain uniforms.
 let code=source.replaceAll('cfg[16].x',String(branchKind)+'.').replaceAll('cfg[9].y',String({cube:0,sphere:1,torus:2,slab:3}[c.shape])+'.');
 // Biaxial presets can reach isotropic or uniaxial limits as indices change.
 // Specialize to the effective model and include it in the pipeline cache key.
 code=code.replaceAll('cfg[0].w',String({isotropic:0,uniaxial:1,common:2,biaxial:3,sphericalSquared:4,radialSquared:5,axialSquared:6,radial:7,axial:8,quadratic:9,heliconical:10,axial2013Uniaxial:11,hyperbolic:12,shear:13,eng2013Magnetic:14}[effectiveMaterial])+'.');
 code=code.replaceAll('cfg[10].w',String({auto:0,schur:1,rkf45:2}[c.solver]??0)+'.');
 const {device}=state,shader=device.createShaderModule({label:'Optics lossless transport',code}),messages=await shader.getCompilationInfo(),errors=messages.messages.filter(m=>m.type==='error');
 if(errors.length)throw Error(errors.map(m=>`WGSL ${m.lineNum}: ${m.message}`).join('\n'));
 timing.shaderModuleMs=performance.now()-compileStart;
 const pipelineStart=performance.now();
 const [init,step]=await Promise.all(['init','step'].map(entryPoint=>device.createComputePipelineAsync({layout:state.pipelineLayout,compute:{module:shader,entryPoint}})));
 timing.pipelineCreationMs=performance.now()-pipelineStart;
 timing.pipelineCompileMs=performance.now()-compileStart;
 const value={init,step};cache.set(key,value);if(cache.size>4)cache.delete(cache.keys().next().value);
 return value;
}
async function create(c,build){
 const policy=GPUOpticsSupport.support(c);if(!policy.ok)throw Error(policy.reason);F.validate(c);const odeControl=O.odeSettings(c);
 const branches=O.branching.settings(c),branchKind=c.branchModel==='coherent'?3:branches.planes.length&&c.branchDepth>0?({equal:1,modal:2}[c.branchModel]||0):0;
 if(!root.navigator?.gpu)throw Error('このブラウザではWebGPUを利用できません。');
 let effective=c,ordinaryMode=0;if(c.material==='biaxial'){if(F.isIso(c))effective={...c,material:'isotropic',n:c.nx};else{const limit=F.uniaxialLimit(c);if(limit){effective=limit.medium;ordinaryMode=limit.ordinaryMode;}}}
 const begin=performance.now(),timing={deviceReused:false,pipelineCacheHit:false,deviceSetupMs:0,sourceLoadMs:0,pipelineCompileMs:0,shaderModuleMs:0,pipelineCreationMs:0,bufferSetupMs:0};
 const buffers=[];const release=()=>{for(const buffer of buffers.splice(0))buffer.destroy();};
 try{
 const {state,reused}=await runtime(build),{device,adapter,layout}=state;
 timing.deviceReused=reused;timing.deviceSetupMs=performance.now()-begin;
 const {init,step}=await pipelines(state,c,branchKind,effective.material,timing),bufferStart=performance.now();
 const makeBuffer=descriptor=>{const buffer=device.createBuffer(descriptor);buffers.push(buffer);return buffer;};
 const maxPixels=Math.min((F.isotropicGradient(c)||F.varying(c))?512:2048,Math.floor(device.limits.maxStorageBufferBindingSize/(CAP*RAY_BYTES))),params=makeBuffer({size:512,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),states=makeBuffer({size:maxPixels*STRIDE,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC}),queue=makeBuffer({size:maxPixels*CAP*RAY_BYTES,usage:GPUBufferUsage.STORAGE}),read=makeBuffer({size:maxPixels*STRIDE,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});
 const group=device.createBindGroup({layout,entries:[{binding:0,resource:{buffer:params}},{binding:1,resource:{buffer:states}},{binding:2,resource:{buffer:queue}}]});
 timing.bufferSetupMs=performance.now()-bufferStart;
 const info={vendor:adapter.info?.vendor||'',architecture:adapter.info?.architecture||'',description:adapter.info?.description||'',isFallbackAdapter:adapter.info?.isFallbackAdapter??null},diagnostics={requested:'gpu',actual:'WebGPU',adapter:info,...timing,initializationMs:performance.now()-begin,gpuPixels:0,cpuFallbackPixels:0,fallbackReasons:{},discardedGpuPackets:0,dispatches:0,computeAndReadbackMs:0,cpuFallbackMs:0,surfaceHits:0,reentries:0,objectPixels:0,internalBranchEvents:0,coherentSegments:0,phaseClosed:0,phaseNumerical:0,trajectoryClosed:0,trajectoryQuadrature:0,trajectoryODE:0,odeAccepted:0,odeRejected:0,odeEvaluations:0,odeFailures:0,odeMaxAcceptedError:0,odeMinStep:0,odeMaxStep:0};
 const eps=c.material==='biaxial'?O.biaxialTensor(c):[[1,0,0],[0,1,0],[0,0,1]],inverse=O.inv(eps),tensorParams=[...eps.flatMap(v=>[...v,0]),...inverse.flatMap(v=>[...v,0])];
 tensorParams[3]={auto:0,schur:1,rkf45:2}[c.solver]??0;tensorParams[7]=c.twist;tensorParams[11]=c.shift;
 const frame=O.cameraFrame(c),N=c.resolution,extent=c.projection==='ortho'?3.4:8*Math.tan(c.fov*Math.PI/360),axis=O.principalAxes(effective)[2],view={all:0,o:1,e:2,mode1:1,mode2:2,reflected:3}[c.transportView];
 function cameraRay(index,y){const x=index%N,j=Math.floor(index/N),u=(x+.5-N/2)/N*extent,v=(N/2-y-j-.5)/N*extent,off=O.add(O.mul(frame.right,u),O.mul(frame.up,v));return {o:c.projection==='ortho'?O.add(frame.eye,off):frame.eye,d:c.projection==='ortho'?frame.forward:O.unit(O.add(O.mul(frame.forward,4),off))};}
 async function renderTile(y,rows){
  if(state.fatal)throw Error(state.fatal);const count=N*rows;if(count>maxPixels)throw Error('GPUのバッチが大きすぎます');const start=performance.now();
  const p=new Float32Array(128);p.set([N,y,rows,{isotropic:0,uniaxial:1,common:2,biaxial:3,sphericalSquared:4,radialSquared:5,axialSquared:6,radial:7,axial:8,quadratic:9,heliconical:10,axial2013Uniaxial:11,hyperbolic:12,shear:13,eng2013Magnetic:14}[effective.material],effective.n,effective.no,effective.ne,O.outsideIndex(c),...axis,c.gradient,c.maxInterfaces,c.minContribution,c.maxRayWork??2048,c.untracedTolerance??.001,...frame.eye,c.projection==='ortho'?1:0,...frame.forward,extent,...frame.right,c.backgroundZ,...frame.up,{grid:0,uv:1,markers:2,white:3,spectralChecker:4,spectralSmooth:5}[c.background],c.step,c.maxSteps||650,O.axisHalfWidth(c),view,count,{cube:0,sphere:1,torus:2,slab:3}[c.shape],ordinaryMode,c.material==='biaxial'?1:0,...tensorParams]);p.set([branchKind,c.branchDepth,branches.planes.length,c.coherentInterface==='resolved'?1:0],64);p.set([2*Math.PI*c.lengthUnitUm/(c.wavelengthNm*.001),c.beamRadiusUm/c.lengthUnitUm*Math.sqrt(-2*Math.log(c.overlapCutoff)),c.phaseSlices,c.phaseTolerance],68);p.set([odeControl.odeRtol,odeControl.odeAtolPosition,odeControl.odeAtolMomentum,odeControl.odeMaxSteps],72);p.set(branches.planes,96);device.queue.writeBuffer(params,0,p);
  let encoder=device.createCommandEncoder(),pass=encoder.beginComputePass();pass.setPipeline(init);pass.setBindGroup(0,group);pass.dispatchWorkgroups(Math.ceil(count/32));pass.end();device.queue.submit([encoder.finish()]);
  let data;const maxRounds=Math.ceil((c.maxRayWork??2048)/32)+2;
  for(let round=0;round<maxRounds;round++){
   if(state.fatal)throw Error(state.fatal);encoder=device.createCommandEncoder();pass=encoder.beginComputePass();pass.setPipeline(step);pass.setBindGroup(0,group);for(let k=0;k<4;k++){pass.dispatchWorkgroups(Math.ceil(count/32));diagnostics.dispatches++;}pass.end();encoder.copyBufferToBuffer(states,0,read,0,count*STRIDE);device.queue.submit([encoder.finish()]);await read.mapAsync(GPUMapMode.READ,0,count*STRIDE);data=read.getMappedRange(0,count*STRIDE).slice(0);read.unmap();
   const ints=new Uint32Array(data);let done=true;for(let i=0;i<count;i++)if(ints[i*64+20]!==1){done=false;break;}if(done)break;if(round===maxRounds-1)throw Error('GPU追跡の終了を確認できません');
  }
  diagnostics.computeAndReadbackMs+=performance.now()-start;const f=new Float32Array(data),u=new Uint32Array(data),results=[];
  for(let i=0;i<count;i++){
   const offset=i*64,v=f.subarray(offset,offset+64),w=u.subarray(offset,offset+64);let reason=w[21];const dropped=v[4]+v[5]+v[6]+v[7]+v[44],accounted=v[3]+dropped;
   if(![v[0],v[1],v[2],accounted].every(Number.isFinite)||Math.abs(accounted-1)>1e-4)reason=reason||8;
   if(reason){diagnostics.odeFailures+=w[59];diagnostics.discardedGpuPackets+=w[13];const t=performance.now(),q=cameraRay(i,y);let r;try{r=F.trace(q.o,q.d,c);}catch(e){r={color:[210,50,100],status:'error',drift:0,message:e.message,failedWeight:1,accounted:1};}diagnostics.cpuFallbackMs+=performance.now()-t;diagnostics.cpuFallbackPixels++;const label=reasons[reason]||String(reason);diagnostics.fallbackReasons[label]=(diagnostics.fallbackReasons[label]||0)+1;r.gpuFallbackReason=label;results.push(r);continue;}
   diagnostics.odeAccepted+=w[56];diagnostics.odeRejected+=w[57];diagnostics.odeEvaluations+=w[58];diagnostics.odeMaxAcceptedError=Math.max(diagnostics.odeMaxAcceptedError,v[60]);if(v[61]>0)diagnostics.odeMinStep=diagnostics.odeMinStep?Math.min(diagnostics.odeMinStep,v[61]):v[61];diagnostics.odeMaxStep=Math.max(diagnostics.odeMaxStep,v[62]);diagnostics.gpuPixels++;diagnostics.trajectoryClosed+=w[22];diagnostics.trajectoryQuadrature+=w[34];diagnostics.trajectoryODE+=w[35];diagnostics.internalBranchEvents+=w[36];diagnostics.coherentSegments+=w[40];diagnostics.phaseClosed+=w[42];diagnostics.phaseNumerical+=w[43];diagnostics.reentries+=v[28];diagnostics.surfaceHits+=v[29];if(v[29]>0)diagnostics.objectPixels++;O.evaluations.closed+=w[22];O.evaluations.quadrature+=w[34];O.evaluations.ode+=w[35];
   results.push(F.finishTraceBudget(c,{status:'ok',color:[v[0],v[1],v[2]].map(F.encode),weightSum:v[3],dropped,failedWeight:0,unavailableWeight:0,accounted,cutoffWeights:{threshold:v[4],interface:v[5],work:v[6],tolerance:v[7],internal:v[44]},workLimitWeight:v[6],processedRays:w[13],maxPendingRays:w[14],maxDepth:v[16],interfaces:v[17],reflections:v[18],leaves:v[19],branches:w[23],fluxError:v[9],boundaryResidual:v[10],drift:v[11],fieldResidual:v[30],rootResidual:v[31],bulkSteps:w[32],bulkSegments:w[33],channels:c.material==='biaxial'?{direct:v[24],mode1:v[25],mode2:v[26],reflected:v[27]}:{direct:v[24],o:v[25],e:v[26],reflected:v[27]},internalBranches:w[36],maxInternalDepth:w[37],modalClosed:w[38],modalQuadrature:w[39],modalWeightError:v[52],modalQuadratureError:v[47],coherentSegments:w[40],coherentSplits:w[41],phaseClosed:w[42],phaseNumerical:w[43],coherentLimitWeight:v[44],phaseIntegrationError:v[45],coherencyError:v[46],phaseBoundaryProjections:w[48],phaseBoundaryTails:w[49],phaseSurfaceDephasings:w[50],phaseReentries:branchKind===3?v[28]:0,phaseEscapedDirect:v[53],phaseEscapedReflected:v[54],geometryResidual:v[55],phaseTransmitted:branchKind===3&&c.coherentInterface==='resolved'?v[51]:0,phaseReflected:branchKind===3&&c.coherentInterface==='resolved'?v[3]-v[51]:0}));
  }
  return results;
 }
 return {renderTile,diagnostics,batchRows:Math.min(16,Math.max(1,Math.floor(maxPixels/N))),destroy:release};
 }catch(e){release();clearCache();throw e;}
}
root.GPUOptics={create,clearCache,support:root.GPUOpticsSupport.support};
})(globalThis);
