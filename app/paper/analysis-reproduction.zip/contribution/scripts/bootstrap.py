"""Optional workspace dependencies; standalone runs use installed packages."""
from pathlib import Path
import sys
for ancestor in Path(__file__).resolve().parents:
    local = ancestor / 'tmp/ao20261112-python'
    if local.is_dir():
        sys.path.insert(0, str(local))
        break
