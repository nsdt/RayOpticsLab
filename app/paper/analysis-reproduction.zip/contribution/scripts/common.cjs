const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const E=require('./engine.cjs');
const T=require('../engine/landmark-target.js');T.install(E.O);
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const config=id=>({...E.base,...read(path.join(root,'configs/manifest.json')).find(s=>s.id===id).config});
const save=(name,data)=>fs.writeFileSync(path.join(root,'data',name+'.json'),JSON.stringify(data,null,2));
module.exports={...E,T,root,read,config,save};
