"""Independent closed expressions; no renderer code is imported."""
from pathlib import Path
import json, math, cmath
R=Path(__file__).resolve().parents[1]
def medium(no,ne,alpha):
 a=math.radians(alpha); d=ne*ne-no*no
 return dict(xx=no*no+d*math.sin(a)**2,zz=no*no+d*math.cos(a)**2,
             xz=d*math.sin(a)*math.cos(a),det=no*no*ne*ne,no=no,ne=ne,alpha=alpha)
def state(m,t,pol,sign=1):
 if pol=='s':
  q=sign*cmath.sqrt(m['no']**2-t*t);Y=q
  E=[0,1,0];direction=[t,0,q.real]
 else:
  b=cmath.sqrt(m['det']*(m['zz']-t*t))
  q=(-m['xz']*t+sign*b)/m['zz'];Y=m['det']/(sign*b)
  E=[(m['zz']*q+m['xz']*t)/m['det'],0,(-m['xz']*q-m['xx']*t)/m['det']]
  direction=[m['xx']*t+m['xz']*q.real,0,m['xz']*t+m['zz']*q.real]
 n=math.sqrt(sum(v*v for v in direction))
 return q,Y,E,[v/n for v in direction]
air=medium(1,1,0);records=[]
for alpha in [0,30,60,90]:
 crystal=medium(1.3,1.15,alpha)
 for reverse in [False,True]:
  ts=[math.sin(math.radians(a)) for a in [0,10,30,50,70]] if not reverse else [0,.5,.9,1.05,1.1]
  for t in ts:
   for pol in ['s','p']:
    a,b=(crystal,air) if reverse else (air,crystal)
    qi,yi,Ei,di=state(a,t,pol);qt,yt,Et,dt=state(b,t,pol)
    qr,yr,Er,dr=state(a,t,pol,-1)
    assert abs(qi.imag)<1e-12
    refl=abs((yi-yt)/(yi+yt))**2
    trans=0 if abs(qt.imag)>1e-12 else 4*yi.real*yt.real/abs(yi+yt)**2
    realE=[complex(v).real for v in Ei];n=math.sqrt(sum(v*v for v in realE))
    records.append(dict(alpha=alpha,reverse=reverse,t=t,pol=pol,
       incident=dict(p=[t,0,qi.real],E=[v/n for v in realE]),
       expected=dict(R=refl,T=trans,reflected_p=[t,0,qr.real],reflected_direction=dr,
                     transmitted_p=None if trans==0 else [t,0,qt.real],
                     transmitted_direction=None if trans==0 else dt)))
(R/'data/interface-input.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
print('Independent interface cases:',len(records))
