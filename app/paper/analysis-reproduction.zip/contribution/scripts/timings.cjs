const {O,F,base,camera,read,root,config,save,equivalence}=require('./common.cjs');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),assert=require('node:assert/strict');
const manifest=read(path.join(root,'configs/manifest.json'));
const specs=manifest.filter(s=>s.role==='representative');
const originalAdvance=O.advance;let counts={closed:0,ode:0,quadrature:0,approximate:0,calls:0};
O.advance=function(...args){
 const before={...O.evaluations};const r=originalAdvance(...args);counts.calls++;
 for(const k of ['closed','ode','quadrature','approximate'])counts[k]+=O.evaluations[k]-before[k];
 return r;
};
function batch(c){
 counts={closed:0,ode:0,quadrature:0,approximate:0,calls:0};O.resetODEStats();
 const colors=[],issues=[];let rays=0,bulkSegments=0,maxDropped=0,interfaces=0;
 const start=performance.now();
 for(let y=0;y<12;y++)for(let x=0;x<12;x++){
  const ray=camera(x*16+7,y*16+7,192,c),a=F.trace(ray.o,ray.d,c);
  if(a.status!=='ok')issues.push(a.message);colors.push(...a.color.map(F.decode));
  rays+=a.processedRays;bulkSegments+=a.bulkSegments;maxDropped=Math.max(maxDropped,a.dropped);interfaces+=a.interfaces;
 }
 const milliseconds=performance.now()-start;
 return {milliseconds,counts:{...counts},odeStats:{...O.odeStats},issues,colors,rays,bulkSegments,interfaces,maxDropped};
}
const records=[];
for(const spec of specs){
 const c={...base,...spec.config,background:'uv',resolution:192};
 // Two complete batches per solver precede measured alternating repetitions.
 for(let j=0;j<2;j++)for(const solver of ['auto','rkf45'])batch({...c,solver});
 const runs={auto:[],rkf45:[]};
 for(let j=0;j<5;j++)for(const solver of (j%2?['rkf45','auto']:['auto','rkf45']))runs[solver].push(batch({...c,solver}));
 const a=runs.auto[0],b=runs.rkf45[0],diff=a.colors.map((v,i)=>v-b.colors[i]);
 for(const solver of ['auto','rkf45'])for(const r of runs[solver]){
  assert.equal(r.issues.length,0,spec.id+': '+r.issues);
  assert.deepEqual(r.colors,runs[solver][0].colors);assert.deepEqual(r.counts,runs[solver][0].counts);
 }
 const median=a=>a.slice().sort((x,y)=>x-y)[Math.floor(a.length/2)];
 const medians=Object.fromEntries(Object.entries(runs).map(([k,v])=>[k,median(v.map(r=>r.milliseconds))]));
 const result={id:spec.id,config:c,medians,speedRatio:medians.rkf45/medians.auto,
  difference:{max:Math.max(...diff.map(Math.abs)),rms:Math.sqrt(diff.reduce((s,v)=>s+v*v,0)/diff.length)},
  runs:Object.fromEntries(Object.entries(runs).map(([k,v])=>[k,v.map(({colors,...r})=>r)])),
  autoColors:a.colors,rkf45Colors:b.colors};
 records.push(result);save('timings',{machine:{cpu:os.cpus()[0].model,logicalCPUs:os.cpus().length,platform:os.platform(),release:os.release(),arch:os.arch(),node:process.version},singleThread:true,sampleGrid:[12,12],virtualResolution:192,warmupBatchesPerSolver:2,repetitions:5,records});
 console.log(spec.id,medians,'ratio',result.speedRatio.toFixed(2),'calls',a.counts,'max difference',result.difference.max);
}