const {O,F,base,camera,T,save}=require('./common.cjs');
const fs=require('node:fs'),path=require('node:path');
const configs=[];
for(const [group,material,parameter,values] of [
 ['reciprocal','common','gradient',[0,.1,.2,.3,.4]],
 ['quadratic','quadratic','gradient',[0,.1,.2,.3,.4]],
 ['heliconical','heliconical','twist',[0,1,2.5,4,6]]])
 for(const value of values)configs.push({group,parameter,value,c:{...base,material,[parameter]:value,paperTarget:'landmarks',resolution:384,odeRtol:1e-11,odeAtolPosition:1e-12,odeAtolMomentum:1e-12}});
function geometry(px,py,c,mode,capture=false){
 try{const ray=camera(px,py,384,c),entry=O.hit(ray.o,ray.d,c.shape);if(!entry)return null;
 const p=O.boundary(entry,ray.d,O.normal(entry,c.shape),c,mode,true);if(!p)return null;
 const E=F.fields(F.cv(p),F.localMaterial(c,entry),mode).E;
 const initial=F.launch(entry,{p,E,mode},c,{}),end=F.propagate(initial,{...c,paperCapture:capture});
 const d=O.exitDirection(end.p,O.normal(end.o,c.shape),c);if(!d)return null;
 const t=O.backgroundDistance(end.o,d,c);if(!Number.isFinite(t))return null;
 return {q:O.add(end.o,O.mul(d,t)),ray,entry,initial,end,d};
 }catch(e){return null;}
}
function solve(start,target,c,mode){
 let [x,y]=start;
 for(let i=0;i<35;i++){
  const a=geometry(x,y,c,mode);if(!a)return null;
  const f=[a.q[0]-target.x,a.q[1]-target.y],err=Math.hypot(...f);
  if(err<1e-9)return {pixel:[x,y],residual:err,...a};
  const h=.002,ax=geometry(x+h,y,c,mode),ay=geometry(x,y+h,c,mode);if(!ax||!ay)return null;
  const aa=(ax.q[0]-a.q[0])/h,b=(ay.q[0]-a.q[0])/h,cc=(ax.q[1]-a.q[1])/h,d=(ay.q[1]-a.q[1])/h,det=aa*d-b*cc;
  if(Math.abs(det)<1e-12)return null;
  const dx=(d*f[0]-b*f[1])/det,dy=(-cc*f[0]+aa*f[1])/det;
  let accepted=false;
  for(let t=1;t>=1/128;t/=2){
   if(Math.hypot(t*dx,t*dy)>20)continue;
   const xx=x-t*dx,yy=y-t*dy;if(xx<0||xx>383||yy<0||yy>383)continue;
   const b=geometry(xx,yy,c,mode);
   if(b&&Math.hypot(b.q[0]-target.x,b.q[1]-target.y)<err){x=xx;y=yy;accepted=true;break;}
  }
  if(!accepted)return null;
 }
 return null;
}
const records=[],missing=[],previous={};
for(const spec of configs){
 const points=[];
 for(const mode of [0,1]){
  const grid=[];
  for(let y=88;y<=296;y+=26)for(let x=88;x<=296;x+=26){const g=geometry(x,y,spec.c,mode);if(g)grid.push({pixel:[x,y],q:g.q});}
  for(const mark of T.landmarks){
   const key=spec.group+'-'+mode+'-'+mark.label;
   const starts=[...(previous[key]?[previous[key]]:[]),...grid.slice().sort((a,b)=>Math.hypot(a.q[0]-mark.x,a.q[1]-mark.y)-Math.hypot(b.q[0]-mark.x,b.q[1]-mark.y)).slice(0,8).map(a=>a.pixel)];
   let found=null;for(const start of starts){found=solve(start,mark,spec.c,mode);if(found)break;}
   if(!found){missing.push({group:spec.group,value:spec.value,mode,label:mark.label});continue;}
   const full=F.trace(found.ray.o,found.ray.d,{...spec.c,paperCapture:true});
   if(full.status!=='ok')throw Error(full.message);
   const leaves=(full.paperLeaves||[]).filter(l=>!l.reflected&&l.segments[0]?.mode===mode&&l.q&&Math.hypot(l.q[0]-mark.x,l.q[1]-mark.y)<1e-7);
   if(!leaves.length)throw Error('unconfirmed landmark '+key);
   previous[key]=found.pixel;
   const refined=geometry(...found.pixel,{...spec.c,step:spec.c.step/2},mode);
   if(!refined)throw Error('refinement failure');
   const confirmation=Math.hypot(refined.q[0]-mark.x,refined.q[1]-mark.y);
   const point={mode,label:mark.label,pixel:found.pixel,u:[(found.pixel[0]+.5)/384-.5,.5-(found.pixel[1]+.5)/384],residual:found.residual,refinedResidual:confirmation,weight:leaves.reduce((s,l)=>s+l.weight,0)};
   points.push(point);
  }
 }
 let separations={},translation=null,residual=null;
 if(points.length===8){
  const disp=T.landmarks.map(m=>{
   const o=points.find(p=>p.mode===0&&p.label===m.label),e=points.find(p=>p.mode===1&&p.label===m.label),d=e.u.map((v,j)=>v-o.u[j]);
   separations[m.label]=100*Math.hypot(...d);return d;
  });
  translation=[0,1].map(j=>disp.reduce((s,d)=>s+d[j],0)/4);
  residual=100*Math.sqrt(disp.reduce((s,d)=>s+d.reduce((a,v,j)=>a+(v-translation[j])**2,0),0)/4);
 }
 records.push({...spec,points,separations,translation,translationResidualPercent:residual});
 save('landmark-sweep',{records,missing});
 console.log(spec.group,spec.value,points.length,'translation residual (%)',residual);
}
