"""Independent normal-incidence Maxwell solution for a continuously rotating axis.

Tangential state f=(Ex,Ey,Z0 Hx,Z0 Hy); z is normalized by L.
Rotation of transverse coordinates makes the 4x4 Maxwell matrix constant.
The matrix exponential is evaluated by eigendecomposition, with an independent
scaling-and-squaring Taylor evaluation used as a numerical cross-check.
"""
from pathlib import Path
import os,sys,json,math
import bootstrap
import numpy as np
R=Path(__file__).resolve().parents[1]
no,ne,theta,omega=1.3,1.15,math.radians(35),2.5
a=np.array([math.sin(theta),0,math.cos(theta)])
eps=no*no*np.eye(3)+(ne*ne-no*no)*np.outer(a,a)
e=eps[:2,:2]-np.outer(eps[:2,2],eps[2,:2])/eps[2,2]
B=np.array([[0,0,0,1],[0,0,-1,0],[-e[1,0],-e[1,1],0,0],[e[0,0],e[0,1],0,0]])
J=np.zeros((4,4));J[:2,:2]=J[2:,2:]=[[0,-1],[1,0]]
def flux(f):return .5*np.real(f[0]*np.conj(f[3])-f[1]*np.conj(f[2]))
vals,P=np.linalg.eig(B)
order=sorted(range(4),key=lambda i:(vals[i]<0,abs(vals[i]-no)>.001,abs(vals[i])))
vals=vals[order];P=P[:,order]
P=P/np.sqrt(np.abs([flux(P[:,i]) for i in range(4)]))
Pinv=np.linalg.inv(P);forward=[i for i,v in enumerate(vals) if v>0];backward=[i for i,v in enumerate(vals) if v<0]
def taylor_expm(A):
 s=max(0,math.ceil(math.log2(max(1,np.linalg.norm(A,np.inf))/.25)))
 Q=A/2**s;term=np.eye(4,dtype=complex);E=term.copy()
 for k in range(1,80):
  term=term@Q/k;E+=term
  if np.linalg.norm(term,np.inf)<1e-17:break
 for _ in range(s):E=E@E
 return E
records=[]
for length_mm in [.05,.1,.5,1,2]:
 wavelength_nm=500;ratio=wavelength_nm/(length_mm*1e6);k0=2*np.pi/ratio
 A=1j*k0*B-omega*J
 w,V=np.linalg.eig(A);Vi=np.linalg.inv(V)
 calc=lambda z:V@np.diag(np.exp(w*z))@Vi
 check=np.max(np.abs(calc(1.4)-taylor_expm(A*1.4)))
 for initial in forward:
  transfer=Pinv@calc(1.4)@P
  entrance=np.zeros(4,dtype=complex);entrance[initial]=1
  entrance[backward]=np.linalg.solve(transfer[np.ix_(backward,backward)],-transfer[backward,initial])
  amplitudes=np.array([Pinv@calc(z)@P@entrance for z in np.linspace(0,1.4,4001)])
  reflected=float(np.sum(np.abs(entrance[backward])**2))
  other=next(i for i in forward if i!=initial)
  refined=np.array([Pinv@calc(z)@P@entrance for z in np.linspace(0,1.4,8001)])
  peak_refinement=float(abs(max(abs(refined[:,other])**2)-max(abs(amplitudes[:,other])**2)))
  conversion=np.abs(amplitudes[:,other])**2
  backward_power=np.sum(np.abs(amplitudes[:,backward])**2,axis=1)
  balance=np.sum(np.abs(amplitudes[:,forward])**2,axis=1)-backward_power
  records.append(dict(length_mm=length_mm,wavelength_nm=wavelength_nm,ratio=ratio,
   mode='ordinary' if abs(vals[initial]-no)<1e-8 else 'extraordinary',
   maxConversion=float(max(conversion)),peakRefinement=peak_refinement,maxBackward=float(max(backward_power)),
   fluxResidual=float(max(abs(balance-(1-reflected)))),entranceReflection=reflected,exponentialCheck=float(check),
   eigenResidual=float(np.linalg.norm(A@V-V@np.diag(w))/np.linalg.norm(A)),
   indexGap=float(abs(vals[forward[0]]-vals[forward[1]])),
   beatToTwist=float(k0*abs(vals[forward[0]]-vals[forward[1]])/omega)))
assert max(r['fluxResidual'] for r in records)<1e-9
assert max(r['exponentialCheck'] for r in records)<1e-8
(R/'data/maxwell-helix.json').write_text(json.dumps(dict(no=no,ne=ne,theta_degrees=35,omega=omega,normalizedLength=1.4,samples=4001,B=B.tolist(),J=J.tolist(),records=records),indent=2),encoding='utf8')
for r in records:print(r['length_mm'],r['mode'],r['maxConversion'],r['exponentialCheck'])
