const {O,F,base,read,root,save}=require('./common.cjs'),path=require('node:path'),assert=require('node:assert/strict');
const rows=read(path.join(root,'data/interface-input.json')),out=[];
function dist(a,b){return Math.hypot(...a.map((v,i)=>v-b[i]));}
for(const r of rows){
 const air={...base,material:'isotropic',n:1},crystal={...base,material:'uniaxial',no:1.3,ne:1.15,tilt:r.alpha,azimuth:0};
 const from=r.reverse?crystal:air,to=r.reverse?air:crystal;
 const s=F.scatter({...r.incident,E:F.cv(r.incident.E)},from,to,[0,0,1]);
 const sums={R:0,T:0};let momentum=0,direction=0;
 for(const ch of s.children){
  const type=ch.reflection?'R':'T';sums[type]+=ch.weight;if(ch.weight<1e-12)continue;
  const prefix=ch.reflection?'reflected':'transmitted',m=ch.reflection?from:to;
  assert(r.expected[prefix+'_p']);
  momentum=Math.max(momentum,dist(ch.p,r.expected[prefix+'_p']));
  const dir=F.rayDirection({...ch,o:[0,0,0]},m);
  direction=Math.max(direction,dist(dir,r.expected[prefix+'_direction']));
 }
 out.push({...r,observed:sums,errors:{R:Math.abs(sums.R-r.expected.R),T:Math.abs(sums.T-r.expected.T),momentum,direction,conservation:s.error,boundary:s.residual}});
}
const max=Object.fromEntries(Object.keys(out[0].errors).map(k=>[k,Math.max(...out.map(r=>r.errors[k]))]));
assert(Math.max(...Object.values(max))<1e-10);
save('interfaces',{description:'Independent admittance formulas for planar uniaxial interfaces; no imported renderer formulas in reference generator.',count:out.length,totalReflection:out.filter(r=>r.expected.T===0).length,max,records:out});
console.log('interfaces',JSON.stringify(max));
const slabs=[];
for(const tilt of [0,30,60,90])for(const angle of [0,10,30,50,70]){
 const t=Math.sin(angle*Math.PI/180),q=Math.cos(angle*Math.PI/180);
 const c={...base,material:'uniaxial',no:1.3,ne:1.15,tilt,azimuth:0,shape:'slab',paperCapture:true,
  minContribution:1e-6,untracedTolerance:0,maxInterfaces:64,maxRayWork:65536};
 const result=F.trace([0,0,4],[t,0,-q],c);assert.equal(result.status,'ok');
 let T=0,R=0;for(const l of result.paperLeaves||[]){if(l.d[2]<0)T+=l.weight;else R+=l.weight;}
 // Axis sign under reverse z leaves the effective admittance unchanged.
 const refs=out.filter(r=>!r.reverse&&r.alpha===tilt&&Math.abs(r.t-t)<1e-14);
 const expectedT=refs.reduce((s,r)=>s+.5*(1-r.expected.R)/(1+r.expected.R),0);
 const expectedR=1-expectedT;
 slabs.push({tilt,angle,T,R,expectedT,expectedR,error:Math.max(Math.abs(T-expectedT),Math.abs(R-expectedR)),dropped:result.dropped,interfaces:result.interfaces});
}
assert(slabs.every(r=>r.error<=r.dropped+1e-12));
save('slabs',{count:slabs.length,maxError:Math.max(...slabs.map(r=>r.error)),maxDropped:Math.max(...slabs.map(r=>r.dropped)),records:slabs});
console.log('slabs',Math.max(...slabs.map(r=>r.error)));
