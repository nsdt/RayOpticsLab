"""Independent tangential Maxwell eigenproblem at an anisotropic interface."""
from pathlib import Path
import os,sys,json,math
import bootstrap
import numpy as np
R=Path(__file__).resolve().parents[1]
def flux(v):return .5*np.real(v[0]*np.conj(v[3])-v[1]*np.conj(v[2]))
def vector(v):return [[float(x.real),float(x.imag)] for x in v]
records=[]
for tilt in [20,50,80]:
 for azimuth in [20,60]:
  th,ph=np.deg2rad([tilt,azimuth]);a=np.array([np.sin(th)*np.cos(ph),np.sin(th)*np.sin(ph),np.cos(th)])
  eps=1.3**2*np.eye(3)+(1.15**2-1.3**2)*np.outer(a,a)
  zz=eps[2,2];e=eps[:2,:2]-np.outer(eps[:2,2],eps[2,:2])/zz
  for angle in [0,20,40,60]:
   t=math.sin(math.radians(angle));q=math.cos(math.radians(angle))
   B=np.array([[-t*eps[2,0]/zz,-t*eps[2,1]/zz,0,1-t*t/zz],
      [0,0,-1,0],[-e[1,0],t*t-e[1,1],0,t*eps[1,2]/zz],
      [e[0,0],e[0,1],0,-t*eps[0,2]/zz]])
   w,V=np.linalg.eig(B);forward=[i for i in range(4) if flux(V[:,i])>0]
   assert len(forward)==2 and max(abs(w.imag))<1e-12
   T=V[:,forward];qs=w[forward]
   reflected=np.array([[0,q],[1,0],[q,0],[0,-1]],complex)
   for pol in ['s','p','diagonal','circular']:
    cs,cp={'s':(1,0),'p':(0,1),'diagonal':(2**-.5,2**-.5),'circular':(2**-.5,1j*2**-.5)}[pol]
    E=np.array([cp*q,cs,-cp*t],complex);H=np.cross([t,0,q],E)
    f=np.array([E[0],E[1],H[0],H[1]])
    amps=np.linalg.solve(np.column_stack([T,-reflected]),f)
    tr=[]
    for j in range(2):
     fv=T[:,j];Ez=-(eps[2,0]*fv[0]+eps[2,1]*fv[1]+t*fv[3])/zz
     Ev=np.array([fv[0],fv[1],Ez]);Hv=np.array([fv[2],fv[3],t*fv[1]])
     S=np.real(np.cross(Ev,np.conj(Hv)));S/=np.linalg.norm(S)
     tr.append(dict(mode=0 if abs(qs[j]-math.sqrt(1.3**2-t*t))<1e-8 else 1,
                    p=[t,0,float(qs[j].real)],direction=S.tolist(),
                    weight=float(abs(amps[j])**2*flux(fv)/flux(f))))
    fr=reflected@amps[2:];ref=-flux(fr)/flux(f)
    records.append(dict(tilt=tilt,azimuth=azimuth,angle=angle,pol=pol,
     incident=dict(p=[t,0,q],E=vector(E)),expected=dict(R=float(ref),transmitted=tr),
     eigenResidual=float(np.linalg.norm(B@V-V@np.diag(w))/np.linalg.norm(B))))
(R/'data/maxwell-interface-input.json').write_text(json.dumps(records,indent=2),encoding='utf8')
print('Independent Maxwell interface cases:',len(records))
