"""Check stored scientific results without rerunning the time measurements."""
from pathlib import Path
import json,math,statistics
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'data'/f'{n}.json').read_text(encoding='utf8'))
def close(a,b):assert math.isclose(a,b,rel_tol=2e-12,abs_tol=2e-15),(a,b)
def finite(v):
 if isinstance(v,float):assert math.isfinite(v)
 elif isinstance(v,dict):
  for x in v.values():finite(x)
 elif isinstance(v,list):
  for x in v:finite(x)
for p in (R/'data').glob('*.json'):finite(json.loads(p.read_text(encoding='utf8')))
a=read('landmark-sweep');assert len(a['records'])==15 and not a['missing']
for r in a['records']:
 assert len(r['points'])==8
 assert r['c']['no']==1.3 and r['c']['ne']==1.15
 ds=[]
 for label in 'UDLR':
  o=next(p for p in r['points'] if p['label']==label and p['mode']==0)
  e=next(p for p in r['points'] if p['label']==label and p['mode']==1)
  d=[x-y for x,y in zip(e['u'],o['u'])];ds.append(d)
  close(100*math.hypot(*d),r['separations'][label])
 mean=[sum(d[j] for d in ds)/4 for j in range(2)]
 for x,y in zip(mean,r['translation']):close(x,y)
 close(100*math.sqrt(sum(sum((d[j]-mean[j])**2 for j in range(2)) for d in ds)/4),r['translationResidualPercent'])
 for p in r['points']:assert p['residual']<1e-9 and p['refinedResidual']<1e-9 and p['weight']>0
for name,count in [('interfaces',80),('maxwell-interfaces',96)]:
 a=read(name);assert a['count']==len(a['records'])==count
 for key,value in a['max'].items():close(value,max(r['errors'][key] for r in a['records']))
 assert max(a['max'].values())<1e-12
assert read('interfaces')['totalReflection']==16
slab=read('slabs');assert slab['count']==len(slab['records'])==20
for r in slab['records']:
 close(r['error'],max(abs(r['T']-r['expectedT']),abs(r['R']-r['expectedR'])))
 assert r['error']<=r['dropped']+1e-12
 close(r['T']+r['R']+r['dropped'],1)
close(slab['maxError'],max(r['error'] for r in slab['records']))
close(slab['maxDropped'],max(r['dropped'] for r in slab['records']))
h=read('maxwell-helix');assert len(h['records'])==10
assert {r['length_mm'] for r in h['records']}=={.05,.1,.5,1,2}
for r in h['records']:
 assert r['fluxResidual']<1e-9 and r['exponentialCheck']<1e-8 and r['peakRefinement']<1e-8
 assert 0<=r['maxConversion']<1 and r['wavelength_nm']==500
v=read('timings');assert len(v['records'])==15 and v['sampleGrid']==[12,12]
for r in v['records']:
 for solver,runs in r['runs'].items():
  assert len(runs)==5
  close(r['medians'][solver],statistics.median(x['milliseconds'] for x in runs))
  for x in runs:
   assert not x['issues'] and x['odeStats']['failures']==0
   assert x['counts']==runs[0]['counts']
   assert x['counts']['quadrature']==x['counts']['approximate']==0
   assert sum(x['counts'][k] for k in ['closed','ode','quadrature','approximate'])==x['counts']['calls']
 close(r['speedRatio'],r['medians']['rkf45']/r['medians']['auto'])
 assert len(r['autoColors'])==len(r['rkf45Colors'])==432
 d=[x-y for x,y in zip(r['autoColors'],r['rkf45Colors'])]
 close(r['difference']['max'],max(map(abs,d)));close(r['difference']['rms'],math.sqrt(sum(x*x for x in d)/len(d)))
assert max(r['difference']['max'] for r in v['records'])<1.2e-7
report={'status':'passed','landmarkConnections':120,'admittanceConditions':80,'maxwellInterfaceConditions':96,'slabConditions':20,'helixIncidencesAndScales':10,'timingConfigurations':15,'timingRepetitionsPerSetting':5,'limits':'Checks consistency of saved results and numerical acceptance criteria; timing values are machine-specific. Does not establish an error bound for complete images.'}
(R/'data/validation.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps(report,indent=2))