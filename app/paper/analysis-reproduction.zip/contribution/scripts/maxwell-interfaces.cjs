const {O,F,base,read,root,save}=require('./common.cjs'),path=require('node:path'),assert=require('node:assert/strict');
const cases=read(path.join(root,'data/maxwell-interface-input.json')),records=[];
const dist=(a,b)=>Math.hypot(...a.map((v,i)=>v-b[i]));
for(const c of cases){
 const air={...base,material:'isotropic',n:1},medium={...base,material:'uniaxial',no:1.3,ne:1.15,tilt:c.tilt,azimuth:c.azimuth};
 const out=F.scatter(c.incident,air,medium,[0,0,1]);
 let R=0,modalWeight=0,momentum=0,direction=0;
 for(const ch of out.children){if(ch.reflection){R+=ch.weight;continue;}
  const ref=c.expected.transmitted.find(t=>t.mode===ch.mode);assert(ref);
  modalWeight=Math.max(modalWeight,Math.abs(ch.weight-ref.weight));
  momentum=Math.max(momentum,dist(ch.p,ref.p));
  direction=Math.max(direction,dist(F.rayDirection({...ch,o:[0,0,0]},medium),ref.direction));
 }
 records.push({...c,errors:{reflection:Math.abs(R-c.expected.R),modalWeight,momentum,direction,conservation:out.error}});
}
const max=Object.fromEntries(Object.keys(records[0].errors).map(k=>[k,Math.max(...records.map(r=>r.errors[k]))]));
assert(Math.max(...Object.values(max))<1e-10);
save('maxwell-interfaces',{count:records.length,max,records});console.log(max);
