from pathlib import Path
import os,sys,json,hashlib,shutil,platform
import bootstrap
import numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];D=R/'data';F=R/'figures';P=R.parent/'manuscript'
read=lambda n:json.loads((D/(n+'.json')).read_text(encoding='utf8'))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':9,'axes.titlesize':10,'legend.fontsize':9,'pdf.fonttype':42})
land=read('landmark-sweep')
fig,axes=plt.subplots(1,3,figsize=(7.3,2.9),sharey=True)
colors=['#0072b2','#d55e00','#008c64','#853c99'];markers=['o','D','s','h']
for ax,group,label in zip(axes,['reciprocal','quadratic','heliconical'],['(a)','(b)','(c)']):
 rows=[r for r in land['records'] if r['group']==group];x=[r['value'] for r in rows]
 for mark,color,marker in zip(['U','D','L','R'],colors,markers):
  ax.plot(x,[r['separations'][mark] for r in rows],color=color,marker=marker,ms=4,lw=1.2,label=mark)
 ax.plot(x,[r['translationResidualPercent'] for r in rows],'k--',marker='x',lw=1.2,ms=4,label='Translation residual')
 ax.set_title(label,loc='left');ax.set_xlabel(r'$\omega$' if group=='heliconical' else '$g$');ax.grid(alpha=.2);ax.set_ylim(0,16)
 if group!='heliconical':ax.set_xticks([0,.1,.2,.3,.4])
axes[0].set_ylabel('Displacement / image width (%)')
fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',ncol=5,frameon=False,bbox_to_anchor=(.53,0))
fig.subplots_adjust(left=.08,right=.99,top=.9,bottom=.25,wspace=.12)
for ext in ['pdf','png']:fig.savefig(F/('quantitative-landmarks.'+ext),dpi=200)
plt.close(fig)
m=read('maxwell-helix');length=sorted({r['length_mm'] for r in m['records']})
power=[max(r['maxConversion'] for r in m['records'] if r['length_mm']==l) for l in length]
fig,ax=plt.subplots(figsize=(4.6,3))
ax.loglog(length,power,'o-',color='#0072b2',lw=1.4,ms=5)
ax.set_xticks(length,[str(l) for l in length]);ax.set_xlabel('$L$ (mm)')
ax.set_ylabel('Transferred power / incident power');ax.grid(which='both',alpha=.2)
fig.tight_layout()
for ext in ['pdf','png']:fig.savefig(F/('mode-coupling.'+ext),dpi=200)
plt.close(fig)
if (P/'figures').is_dir():
 for name in ['quantitative-landmarks','mode-coupling']:
  for ext in ['pdf','png']:shutil.copy2(F/(name+'.'+ext),P/'figures'/(name+'.'+ext))
summary={'landmark':{'connections':sum(len(r['points']) for r in land['records']),'missing':land['missing'],
 'maxResidual':max(p['residual'] for r in land['records'] for p in r['points']),
 'maxRefinedResidual':max(p['refinedResidual'] for r in land['records'] for p in r['points'])},
 'interfaces':{k:v for k,v in read('interfaces').items() if k!='records'},
 'maxwellInterfaces':{k:v for k,v in read('maxwell-interfaces').items() if k!='records'},
 'slabs':{k:v for k,v in read('slabs').items() if k!='records'},
 'helix':{'maximumPower':dict(zip(map(str,length),power)),
  'fluxResidual':max(r['fluxResidual'] for r in m['records']),
  'exponentialCheck':max(r['exponentialCheck'] for r in m['records']),
  'peakRefinement':max(r['peakRefinement'] for r in m['records']),
  'maximumEntranceReflection':max(r['entranceReflection'] for r in m['records'])},
 'timing':{'maximumDifference':max(r['difference']['max'] for r in read('timings')['records']),
 'minimumRatio':min(r['speedRatio'] for r in read('timings')['records']),
 'maximumRatio':max(r['speedRatio'] for r in read('timings')['records'])}}
(D/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps(summary,indent=2))
