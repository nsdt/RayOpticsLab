const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../engine');
const O=require(path.join(root,'optics.js'));
for(const name of ['analytical','schur','approximate','homogeneous','grin','branching','polarization']) require(path.join(root,name+'.js'));
for(const name of ['data/spectral/cie-visible','data/spectral/schott-visible','spectral']) require(path.join(root,name+'.js'));
const originalTrace=O.polarization.trace;
let source=fs.readFileSync(path.join(root,'polarization.js'),'utf8');
const edits=[];
function replace(a,b,count=1){assert.equal(source.split(a).length-1,count,a);source=source.split(a).join(b);edits.push({before:a,after:b,count});}
replace('const initial=[...packet.o,...packet.p];','const initial=[...packet.o,...packet.p],paperSegment=c.paperCapture?[initial.slice()]:undefined;');
replace("O.recordStep('closed');return event||{...packet,o:x};","if(paperSegment)paperSegment.push([...x,...packet.p]);O.recordStep('closed');return event||{...packet,o:x,paperSegment};");
replace('return {...packet,o:s.slice(0,3),p:s.slice(3),E:isotropicGradient(c)?E:bulkField(packet,s,c)};', 'if(paperSegment)paperSegment.push(s.slice());return {...packet,o:s.slice(0,3),p:s.slice(3),E:isotropicGradient(c)?E:bulkField(packet,s,c),paperSegment};');
replace('checkState(next,c,packet.mode,stats);if(isotropicGradient(c))E=transportIsotropic(E,s,next);s=next;', 'checkState(next,c,packet.mode,stats);if(isotropicGradient(c))E=transportIsotropic(E,s,next);s=next;if(paperSegment)paperSegment.push(s.slice());');
replace('r.leaves++;r.weightSum+=v.weight;r.channels[v.tag]+=v.weight;',`r.leaves++;r.weightSum+=v.weight;r.channels[v.tag]+=v.weight;
    if(c.paperChannels||c.paperCapture){
      const rgb=O.bg(v.o,dir,c).map(decode),t=O.backgroundDistance(v.o,dir,c),q=Number.isFinite(t)?O.add(v.o,O.mul(dir,t)):null;
      r.paperChannels??={};for(const key of [v.tag,...(v.reflected?['any_reflection']:[])]){r.paperChannels[key]??=[0,0,0];for(let j=0;j<3;j++)r.paperChannels[key][j]+=rgb[j]*v.weight;}
      if(!v.reflected&&q){r.paperDirect??={};let z=r.paperDirect[v.tag]??={q:[0,0,0],weight:0};for(let j=0;j<3;j++)z.q[j]+=q[j]*v.weight;z.weight+=v.weight;}
      if(c.paperCapture){r.paperLeaves??=[];r.paperLeaves.push({o:v.o,d:dir,q,weight:v.weight,tag:v.tag,reflected:v.reflected,events:v.paperEvents||[],segments:v.paperSegments||[]});}
    }`);
replace('tag,reflected:v.reflected||ch.reflection});',`tag,reflected:v.reflected||ch.reflection,
      ...(c.paperCapture?{paperEvents:[...(v.paperEvents||[]),{position:x.slice(),incoming:incoming.p.slice(),outgoing:ch.p.slice(),insideBefore:v.inside,insideAfter:inside,mode:ch.mode,reflection:ch.reflection,weight}],paperSegments:[...(v.paperSegments||[]),...(incoming.paperSegment?[{mode:v.mode,states:incoming.paperSegment}]:[])]}:{})});`);
replace('const weight=v.weight*ch.weight;', 'const weight=v.weight*ch.weight;if(c.paperDirectOnly&&ch.reflection){r.excludedReflectionWeight=(r.excludedReflectionWeight||0)+weight;continue;}');
replace('r.accounted=r.weightSum+r.dropped+r.failedWeight+r.unavailableWeight;', 'r.accounted=r.weightSum+r.dropped+r.failedWeight+r.unavailableWeight+(r.excludedReflectionWeight||0);');
vm.runInThisContext(source,{filename:'paper-diagnostics-polarization.js'});
const F=O.polarization;
const base={...O.defaults,material:'common',shape:'asphere',transport:'polarized',transportView:'all',branchPolicy:'off',branchModel:'equal',solver:'auto',paperRKF45Fallback:true,projection:'perspective',fov:40,yaw:0,pitch:0,cameraSide:'positive',backgroundZ:-3,background:'grid',no:1.3,ne:1.15,n:1.3,tilt:35,azimuth:20,gradient:.15,step:.06,maxSteps:2000,maxInterfaces:32,maxRayWork:32768,minContribution:1e-6,untracedTolerance:1e-5,odeRtol:1e-9,odeAtolPosition:1e-11,odeAtolMomentum:1e-11,odeMaxSteps:1024,resolution:128,spectralMode:'off',wavelengthNm:550,computeBackend:'cpu'};
function camera(x,y,n,c){const {eye,forward,right,up}=O.cameraFrame(c),scale=c.projection==='ortho'?3.4:8*Math.tan(c.fov*Math.PI/360),u=(x+.5-n/2)/n*scale,v=(n/2-y-.5)/n*scale,off=O.add(O.mul(right,u),O.mul(up,v));return {o:c.projection==='ortho'?O.add(eye,off):eye,d:c.projection==='ortho'?forward:O.unit(O.add(O.mul(forward,4),off))};}
function trace(o,d,c){return F.trace(o,d,c);}
function equivalence(c){if(c.paperDirectOnly)return null;let max=0;for(const [x,y] of [[.0,.0],[.2,.1],[-.4,.1],[.6,-.3]]){const q=camera((x+.5)*32-.5,(y+.5)*32-.5,32,c),a=originalTrace(q.o,q.d,c),b=F.trace(q.o,q.d,{...c,paperCapture:true,paperChannels:true});assert.deepEqual(a.color,b.color);for(const key of ['status','dropped','failedWeight','interfaces','processedRays'])assert.deepEqual(a[key],b[key]);max=Math.max(max,...a.color.map((v,i)=>Math.abs(v-b.color[i])));}return max;}
module.exports={O,F,base,camera,trace,equivalence,edits,originalTrace};
