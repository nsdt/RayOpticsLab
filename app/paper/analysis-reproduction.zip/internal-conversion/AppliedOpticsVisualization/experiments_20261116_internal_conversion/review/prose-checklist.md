# Interpretation checklist
- Distinguish the original uncoupled-ray assumption from demonstrated small coupling.
- Do not treat unsupported radial switch settings as a valid on/off calculation.
- Restrict radial decoupling to the smooth spherically symmetric interior; retain surface mode conversion.
- Qualify heliconical cancellation by the mode history between entrance and exit.
- Separate exact Maxwell slab checks, forward packet image comparisons, numerical tolerances, dropped/fallback weights, and omitted diffraction.
- State the wavelength, physical length, packet radius, and projection assumptions for every coupled comparison.
- Do not infer an image-error bound from a normal-incidence converted-power fraction.
- Review each English proposal before drafting the next. Canonical article and image configurations remain the comparison reference.
