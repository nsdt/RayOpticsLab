from pathlib import Path
import sys,json
ROOT=Path.cwd();R=ROOT/'AppliedOpticsVisualization/experiments_20261116_internal_conversion';sys.path.insert(0,str(ROOT/'tmp/ao20261112-python'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
a=np.fromfile(R/'data/radial-reference.f64','<f8');n=int(np.sqrt(a.size/3));a=a.reshape(n,n,3);display=np.clip(np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055),0,1)
saved=json.loads((R/'data/archived-radial/radial-axis.json').read_text());sample=next(x for x in saved['samples']if x['sample']=='P0');fig,axs=plt.subplots(1,2,figsize=(9,4),gridspec_kw={'width_ratios':[1,1.6]});fig.subplots_adjust(left=.02,right=.98,bottom=.14,top=.88,wspace=.25);axs[0].imshow(display);axs[0].set_title('(a) Radial optical axis, $R_r=7$');axs[0].axis('off')
ax=axs[1];rr=np.linspace(-1,1,300);zz=1-rr**2/(.6+np.sqrt(.36+.69*rr**2));ax.fill_betweenx(rr,-1,zz,color='#e9edf0');ax.plot(zz,rr,color='#7b8891',lw=.8);ax.plot([-1,-1],[-1,1],color='#7b8891',lw=.8)
for mode,col,style,label in [(0,'#167db1','-','Ordinary'),(1,'#cb6b24','--','Extraordinary')]:
 p=next(p for p in sample['paths']if p['initialMode']==mode);seg=p['segments'][0];s=np.asarray(seg['states']);t=(2*s[:,0]+s[:,1])/np.sqrt(5);ax.plot(s[:,2],t,style,color=col,lw=1.8,label=label)
 for idx in np.linspace(0,len(s)-1,4,dtype=int):
  z=s[idx,2];v=t[idx];vec=np.array([z+3,v-np.sqrt(5)]);vec=.24*vec/np.linalg.norm(vec);ax.arrow(z,v,*vec,color='#777777',width=.008,head_width=.055,length_includes_head=True,alpha=.55)
ax.plot(-3,np.sqrt(5),'*',color='black',ms=10);ax.text(-2.8,2.22,r'$\bm{c}_r$'.replace(r'\bm{c}',r'\mathbf{c}'),va='center');ax.text(1.7,.65,r'$\mathbf{E}_o\perp$ plane',color='#167db1');ax.text(1.7,.4,r'$\mathbf{E}_e\in$ plane',color='#cb6b24');ax.set(xlim=(-3.4,4.1),ylim=(-.7,2.6),xlabel='$z/L$',ylabel=r'$(2x+y)/(\sqrt{5}L)$',title='(b) Central rays in their invariant plane');ax.legend(frameon=False,loc='lower right');ax.grid(alpha=.17)
fig.savefig(R/'figures/radial-symmetry.png',dpi=200,bbox_inches='tight')
