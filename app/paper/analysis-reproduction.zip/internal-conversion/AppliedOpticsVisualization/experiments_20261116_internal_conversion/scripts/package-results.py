from pathlib import Path
import sys,json,hashlib,zipfile
sys.path.insert(0,str(Path.cwd()/'tmp/ao20261112-python'))
import numpy as np
R=Path('AppliedOpticsVisualization/experiments_20261116_internal_conversion')
s=json.loads((R/'data/summary.json').read_text())
assert len(s['images'])==2 and len(s['criticalChecks'])==2
assert len(json.loads((R/'data/grid-samples.json').read_text()))==441
assert len(json.loads((R/'data/grid-narrow.json').read_text()))==294
assert sum(x['states']for x in s['radial'])==6081
for L in [50,1000]:
 for kind in ['on','off','diagnostics']:
  a=np.fromfile(R/f'data/heliconical-L{L}-{kind}.f64','<f8');assert a.size==256*256*3 and np.all(np.isfinite(a))
assert (R/'data/heliconical-L1000-off.f64').read_bytes()==(R/'data/heliconical-L50-off.f64').read_bytes()
for row in json.loads((R/'data/source-provenance.json').read_text()):
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
assert '__IMAGE_'not in(R/'REPORT_JA.md').read_text()
exclude={'engine/power-phase.js','data/pilot.json','data/power-phase-validation.json','data/su2-beat8-validation.json','data/render-progress.json','scripts/audit-unit.py','MANIFEST_SHA256.json'}
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R).as_posix()
 if rel in exclude or '__pycache__'in rel:continue
 if rel.startswith('scripts/')and(p.name.startswith('pilot')or p.name in ['profile.cjs','validate-beat8.cjs','validate-power.cjs','validate-power-strict.cjs']):continue
 files.append(p)
manifest=[{'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in files]
(R/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,indent=2))
files.append(R/'MANIFEST_SHA256.json')
out=Path('AppliedOpticsVisualization/internal_conversion_comparison_20261116.zip')
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in files:z.write(p,p.as_posix())
with zipfile.ZipFile(out)as z:assert z.testzip()is None
print(json.dumps({'files':len(files),'zipBytes':out.stat().st_size,'zipSha256':hashlib.sha256(out.read_bytes()).hexdigest(),'checkedPixels':s['criticalChecks'],'verified':'Finite arrays, identical uncoupled images, source files unchanged, archive CRC valid'},indent=2))
