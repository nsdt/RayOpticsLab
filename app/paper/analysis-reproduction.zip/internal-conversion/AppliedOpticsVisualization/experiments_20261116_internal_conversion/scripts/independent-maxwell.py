from pathlib import Path
import sys,json,math
sys.path.insert(0,str(Path.cwd()/'tmp/ao20261112-python'))
import numpy as np
R=Path('AppliedOpticsVisualization/experiments_20261116_internal_conversion')
no,ne,theta=1.3,1.15,math.radians(35)
a=np.array([math.sin(theta),0,math.cos(theta)]);eps=no*no*np.eye(3)+(ne*ne-no*no)*np.outer(a,a);e=eps[:2,:2]-np.outer(eps[:2,2],eps[2,:2])/eps[2,2]
B=np.array([[0,0,0,1],[0,0,-1,0],[-e[1,0],-e[1,1],0,0],[e[0,0],e[0,1],0,0]])
rot=np.zeros((4,4));rot[:2,:2]=rot[2:,2:]=[[0,-1],[1,0]]
flux=lambda f:.5*np.real(f[0]*np.conj(f[3])-f[1]*np.conj(f[2]))
vals,P=np.linalg.eig(B);P=P/np.sqrt(np.abs([flux(P[:,i])for i in range(4)]));Pinv=np.linalg.inv(P);forward=[i for i,v in enumerate(vals)if v>0];backward=[i for i,v in enumerate(vals)if v<0];neff=no*ne/np.sqrt(no*no*np.sin(theta)**2+ne*ne*np.cos(theta)**2)
rows=[]
for omega in [0,1,2.5,np.pi,4,6]:
 for L in [50,1000]:
  k0=2*np.pi*L/.55;A=1j*k0*B-omega*rot;w,V=np.linalg.eig(A);Vi=np.linalg.inv(V);C=Pinv@V;zs=np.linspace(0,2,8001);T=C@np.diag(np.exp(w*2))@Vi@P
  g=.5*(np.sqrt(no/neff)+np.sqrt(neff/no))*omega;delta=k0*(no-neff)/2;r=np.hypot(g,delta);forwardPower=(g/r*np.sin(r*zs))**2 if r else np.zeros_like(zs)
  record={'omega':float(omega),'L_um':L,'wavelength_nm':550,'thickness_over_L':2,'forwardMax':float(max(forwardPower)),'forwardEnd':float(forwardPower[-1]),'modes':[]}
  for initial in forward:
   entrance=np.zeros(4,dtype=complex);entrance[initial]=1;entrance[backward]=np.linalg.solve(T[np.ix_(backward,backward)],-T[backward,initial]);amps=C@(np.exp(w[:,None]*zs[None,:])*(Vi@P@entrance)[:,None]);other=next(i for i in forward if i!=initial);power=abs(amps[other])**2;balance=np.sum(abs(amps[forward])**2,axis=0)-np.sum(abs(amps[backward])**2,axis=0);reflected=float(np.sum(abs(entrance[backward])**2));record['modes'].append({'incidentIndex':float(np.real(vals[initial])),'maxConversion':float(max(power)),'endConversion':float(power[-1]),'maxPowerDifferenceFromForward':float(max(abs(power-forwardPower))),'fluxError':float(max(abs(balance-(1-reflected)))),'entranceReflection':reflected})
  rows.append(record)
(R/'data/independent-maxwell.json').write_text(json.dumps(rows,indent=2));print([(r['omega'],r['L_um'],max(m['maxConversion']for m in r['modes']))for r in rows])
