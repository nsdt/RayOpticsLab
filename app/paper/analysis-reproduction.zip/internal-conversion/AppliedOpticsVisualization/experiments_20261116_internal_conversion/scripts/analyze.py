from pathlib import Path
import sys,json,math,collections
ROOT=Path.cwd();R=ROOT/'AppliedOpticsVisualization/experiments_20261116_internal_conversion';sys.path.insert(0,str(ROOT/'tmp/ao20261112-python'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11,'axes.labelsize':10})
load=lambda n:json.loads((R/'data'/n).read_text(encoding='utf8'))
radial=load('radial-audit.json');central=load('central-rays.json');maxwell=load('independent-maxwell.json');grid=load('grid-samples.json');control=load('geometry-control.json');summary={'radial':radial,'grid':[],'images':[],'centralPi':[x for x in central if x['id']=='heliconical-pi'],'geometryControl':{'rays':len(control),'maxDifference':max(x['difference']for x in control)}}
for (name,L),rows in __import__('itertools').groupby(sorted(grid,key=lambda x:(x['id'],x['L'])),key=lambda x:(x['id'],x['L'])):
 rows=[x for x in rows if x['inLens']];summary['grid'].append({'id':name,'L_um':L,'rays':len(rows),'maxLinearDifference':max(x['difference']for x in rows),'meanMaxChannelDifference':float(np.mean([x['difference']for x in rows])),'maxFailed':max(x['failed']for x in rows),'maxFallback':max(x['fallback']for x in rows)})
fig,axs=plt.subplots(1,2,figsize=(10.2,3.7));fig.subplots_adjust(left=.08,right=.97,bottom=.18,top=.88,wspace=.32)
for L,col in [(1000,'#147eb3'),(50,'#d06020')]:
 rows=[x for x in maxwell if x['L_um']==L];xs=[x['omega']for x in rows];ys=[max(m['maxConversion']for m in x['modes'])for x in rows];axs[0].semilogy(xs[1:],ys[1:],'o-',color=col,label=f'$L={L/1000:g}$ mm')
axs[0].set(xlabel=r'Twist rate $\omega$',ylabel='Maximum converted power fraction',title='(a) Independent normal-incidence Maxwell calculation',xticks=[0,1,2.5,math.pi,4,6],xticklabels=['0','1','2.5',r'$\pi$','4','6']);axs[0].legend(frameon=False);axs[0].grid(alpha=.2)
for L,col in [(1000,'#147eb3'),(50,'#d06020')]:
 rows=sorted([x for x in central if x['L']==L and x['beamRadiusRatio']==.02],key=lambda x:x['omega']);axs[1].plot([x['omega']for x in rows],[x['after']['rmsRadius']for x in rows],'o-',color=col,label=f'Coupled, $L={L/1000:g}$ mm')
rows=sorted([x for x in central if x['L']==1000 and x['beamRadiusRatio']==.02],key=lambda x:x['omega']);axs[1].plot([x['omega']for x in rows],[x['before']['rmsRadius']for x in rows],'k--',label='Uncoupled');axs[1].set(xlabel=r'Twist rate $\omega$',ylabel=r'RMS background radius / $L$',title='(b) Central direct paths, packet radius $0.02L$',xticks=[0,1,2.5,math.pi,4,6],xticklabels=['0','1','2.5',r'$\pi$','4','6']);axs[1].legend(frameon=False,fontsize=8.5);axs[1].grid(alpha=.2)
fig.savefig(R/'figures/coupling-and-central-rays.png',dpi=200,bbox_inches='tight');plt.close(fig)
mask=np.fromfile(R/'data/lens-mask.u8','u1').reshape(256,256).astype(bool)
display=lambda a:np.clip(np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055),0,1)
available=[L for L in [1000,50]if(R/'data'/f'heliconical-L{L}.json').exists()]
if available:
 fig,axs=plt.subplots(len(available),3,figsize=(10,3.5*len(available)),squeeze=False);fig.subplots_adjust(left=.02,right=.96,bottom=.04,top=.94,wspace=.22,hspace=.28)
 for row,L in enumerate(available):
  name=f'heliconical-L{L}';off=np.fromfile(R/'data'/(name+'-off.f64'),'<f8').reshape(256,256,3);on=np.fromfile(R/'data'/(name+'-on.f64'),'<f8').reshape(256,256,3);diag=np.fromfile(R/'data'/(name+'-diagnostics.f64'),'<f8').reshape(256,256,3);diff=np.max(abs(on-off),axis=2);d8=np.max(abs(np.rint(255*display(on))-np.rint(255*display(off))),axis=2);indices=np.flatnonzero(mask);critical=sorted(indices,key=lambda i:diff.flat[i],reverse=True)[:100]
  record={'L_um':L,'lensPixels':int(mask.sum()),'meanAbsoluteLinearDifference':float(np.mean(abs(on-off)[mask])),'rmsLinearDifference':float(np.sqrt(np.mean((on-off)[mask]**2))),'maximumLinearDifference':float(diff[mask].max()),'p99MaximumChannelDifference':float(np.quantile(diff[mask],.99)),'maximum8bitDifference':int(d8[mask].max()),'fractionAbove1DisplayLevel':float(np.mean(d8[mask]>1)),'pixelsWithFailedWeight':int(np.sum(diag[:,:,0][mask]>0)),'maxFailedWeight':float(diag[:,:,0].max()),'maxDroppedWeight':float(diag[:,:,1].max()),'maxAdiabaticFallbackExposure':float(diag[:,:,2].max()),'meanAdiabaticFallbackExposure':float(diag[:,:,2][mask].mean()),'criticalPixels':[{'x':int(i%256),'y':int(i//256),'difference':float(diff.flat[i])}for i in critical]};valid=mask & (diag[:,:,0]==0)
  record.update({'completeLensPixels':int(valid.sum()),'completeMeanAbsoluteLinearDifference':float(np.mean(abs(on-off)[valid])),'completeRmsLinearDifference':float(np.sqrt(np.mean((on-off)[valid]**2))),'completeMaximumLinearDifference':float(diff[valid].max()),'completeMaximum8bitDifference':int(d8[valid].max()),'completeFractionAbove1DisplayLevel':float(np.mean(d8[valid]>1))})
  summary['images'].append(record)
  for col,(im,title)in enumerate([(display(off),'Uncoupled'),(display(on),'Phase retained, packet radius $2L$')]):axs[row,col].imshow(im,interpolation='nearest');axs[row,col].set_title(f'{title}\n$L={L/1000:g}$ mm');axs[row,col].axis('off')
  vmax=max(float(diff.max()),1e-7);cm=plt.get_cmap('magma').copy();cm.set_bad('#bbbbbb');im=axs[row,2].imshow(np.ma.masked_where(diag[:,:,0]>0,diff),cmap=cm,vmin=0,vmax=vmax,interpolation='nearest');axs[row,2].set_title('Maximum linear-channel difference\nIncomplete pixels masked in gray');axs[row,2].axis('off');fig.colorbar(im,ax=axs[row,2],fraction=.045,pad=.025)
 fig.savefig(R/'figures/heliconical-image-comparison.png',dpi=200,bbox_inches='tight');plt.close(fig)
if (R/'data/grid-narrow.json').exists():
 narrow=load('grid-narrow.json');summary['narrowGrid']=[]
 for (name,L),rows in __import__('itertools').groupby(sorted(narrow,key=lambda x:(x['id'],x['L'])),key=lambda x:(x['id'],x['L'])):
  rows=[x for x in rows if x['inLens']];summary['narrowGrid'].append({'id':name,'L_um':L,'rays':len(rows),'maxLinearDifference':max(x['difference']for x in rows),'maxFailed':max(x['failed']for x in rows),'maxDropped':max(x['dropped']for x in rows),'maxFallback':max(x['fallback']for x in rows)})
if (R/'data/critical-pixel-checks.json').exists():
 checks=load('critical-pixel-checks.json');summary['criticalChecks']=[]
 for L in sorted(set(x['L']for x in checks)):
  rows=[x for x in checks if x['L']==L];complete=[x for x in rows if x['controlFailed']==0];on=np.fromfile(R/f'data/heliconical-L{L}-on.f64','<f8').reshape(256,256,3);strict=[x for x in rows if isinstance(x.get('strict'),dict)]
  summary['criticalChecks'].append({'L_um':L,'checked':len(rows),'controlComplete':len(complete),'maxCompleteControlDifference':max(x['controlDifference']for x in complete),'strictCount':len(strict),'maxStrictDifference':max(float(max(abs(np.array(x['strict']['linear'])-on[x['y'],x['x']])))for x in strict),'strictIncomplete':sum(x['strict']['failed']>0 for x in strict)})
(R/'data/summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'grid':summary['grid'],'images':[{k:v for k,v in x.items()if k!='criticalPixels'}for x in summary['images']]},indent=2))
