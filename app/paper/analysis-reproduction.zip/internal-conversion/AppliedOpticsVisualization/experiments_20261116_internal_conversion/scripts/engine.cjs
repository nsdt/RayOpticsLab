const fs=require('node:fs'),path=require('node:path'),root=path.resolve(__dirname,'../engine'),O=require(path.join(root,'optics.js'));
for(const n of ['analytical','schur','approximate','homogeneous','grin','branching','polarization','data/spectral/cie-visible','data/spectral/schott-visible','spectral','protocol'])require(path.join(root,n+'.js'));
const F=O.polarization,uncoupled=F.trace;
for(const n of ['polynomial','layered','modal','coherent','coherent-general','coherent-interface','coherent-finite','fast-helix','fast-phase'])require(path.join(root,n+'.js'));
module.exports={O,F,P:globalThis.PaperProtocol,uncoupled};
// Diagnostic control: retain the same paired-ray geometry and interface code,
// but suppress only interior o/e coupling. Relative pure-mode phase cannot
// change modal powers at the explicitly incoherent interface projections.
const originalGeneralTransport=F.coherentGeneral.transport;
F.coherentGeneral.transport=(S,z0,z1,k,c,sign)=>c.suppressCoupling?{S:S.slice(),transfer:{method:'closed',error:0,evaluations:0,accepted:0,conversion:0}}:originalGeneralTransport(S,z0,z1,k,c,sign);
