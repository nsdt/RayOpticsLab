(function(O,F){
'use strict';
const mul=(A,B)=>[A[0]*B[0]-A[1]*B[1]-A[2]*B[2]-A[3]*B[3],A[0]*B[1]+A[1]*B[0]+A[2]*B[3]-A[3]*B[2],A[0]*B[2]-A[1]*B[3]+A[2]*B[0]+A[3]*B[1],A[0]*B[3]+A[1]*B[2]-A[2]*B[1]+A[3]*B[0]];
const diff=(A,B)=>Math.max(Math.hypot(A[0]-B[0],A[1]-B[1]),Math.hypot(A[2]-B[2],A[3]-B[3]));
function exp(g,d,h){const r=Math.hypot(g,d),q=r?Math.sin(r*h)/r:h;return [Math.cos(r*h),d*q,g*q,0];}
let cacheKey='',cache=new Map();
function transfer(z0,z1,k,c,sign){
 const mat=JSON.stringify([c.material,c.no,c.ne,c.gradient,c.tilt,c.azimuth,c.twist,c.lengthUnitUm,c.wavelengthNm,c.phaseTolerance,c.phaseSlices,c.phaseBeatLimit]);if(mat!==cacheKey){cacheKey=mat;cache.clear();}const key=JSON.stringify([z0,z1,k,sign]);if(cache.has(key))return cache.get(key);
 let J=[1,0,0,0],evaluations=0,error=0,accepted=0,method='numerical';const memo=new Map(),at=z=>{if(memo.has(z))return memo.get(z);if(++evaluations>50000)throw Error('偏光輸送が計算上限に達しました');const a=F.fastHelix.coefficients(z,k,c,sign);memo.set(z,a);return a;};
 if(z0===z1)method='closed';else if(Math.hypot(...k)<1e-10){const a=at((z0+z1)/2);J=exp(a.g,a.delta,z1-z0);method='closed';accepted=1;}else{
  const v=Math.sqrt(3)/6,a=(3-2*Math.sqrt(3))/12,b=(3+2*Math.sqrt(3))/12;
  const cf=(x,y)=>{const h=y-x,A=at(x+(.5-v)*h),B=at(x+(.5+v)*h);return mul(exp(a*A.g+b*B.g,a*A.delta+b*B.delta,h),exp(b*A.g+a*B.g,b*A.delta+a*B.delta,h));};
  function rec(x,y,tol,depth){const mid=(x+y)/2,left=cf(x,mid),right=cf(mid,y),fine=mul(right,left),coarse=cf(x,y),err=diff(fine,coarse)/15,A=at(x),B=at(mid),D=at(y),beat=Math.max(Math.abs(A.delta),Math.abs(B.delta),Math.abs(D.delta))*Math.abs(y-x);if(err<=tol&&(beat<=(c.phaseBeatLimit||1)||Math.max(Math.abs(A.g),Math.abs(B.g),Math.abs(D.g))<1e-14)){error+=err;accepted+=2;return fine;}if(!depth)throw Error('偏光輸送が収束しません');return mul(rec(mid,y,tol/2,depth-1),rec(x,mid,tol/2,depth-1));}
  const n=Math.max(c.phaseSlices||1,Math.ceil(Math.abs(z1-z0)*Math.abs(c.twist)/.2),1),tol=c.phaseTolerance||2e-6;for(let i=0;i<n;i++)J=mul(rec(z0+(z1-z0)*i/n,z0+(z1-z0)*(i+1)/n,tol/n,18),J);
 }
 const j=[[[J[0],J[1]],[J[2],J[3]]],[[-J[2],J[3]],[J[0],-J[1]]]],M=F.layered.jonesMueller(j),result={J:j,M,method,error,evaluations,accepted,conversion:J[2]*J[2]+J[3]*J[3]};if(cache.size>=1024)cache.clear();cache.set(key,result);return result;
}
F.fastPhase={transfer};
})(globalThis.Optics,globalThis.Optics.polarization);
