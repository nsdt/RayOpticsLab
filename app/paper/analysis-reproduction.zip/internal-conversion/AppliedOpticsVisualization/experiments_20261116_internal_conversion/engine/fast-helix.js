/* Exact real-valued heliconical eigenfields and their z derivatives.
   Replaces repeated complex field construction and finite differences only.
   The forward coupled-mode model and CF4 phase integrator are unchanged. */
(function(O,F){
'use strict';
const add=O.add,mul=O.mul,cross=O.cross,dot=O.dot;
function frame(z,k,c,sign){
 const th=c.tilt*Math.PI/180,ph=c.azimuth*Math.PI/180+c.twist*z,a=[Math.sin(th)*Math.cos(ph),Math.sin(th)*Math.sin(ph),Math.cos(th)],da=[-c.twist*a[1],c.twist*a[0],0];
 const s=1/c.ne**2,t=1/c.no**2-s,K=a[0]*k[0]+a[1]*k[1],dK=da[0]*k[0]+da[1]*k[1],A=s+t*a[2]**2,B=t*a[2]*K,dB=t*a[2]*dK,C=s*dot(k,k)+t*K*K-1,dC=2*t*K*dK,D=B*B-A*C;
 if(!(D>1e-14&&c.no*c.no-dot(k,k)>1e-14))throw Error('前方2モードの伝播条件外');
 const root=Math.sqrt(D),qe=(-B+sign*root)/A,dqe=(-dB+sign*(2*B*dB-A*dC)/(2*root))/A,qo=sign*Math.sqrt(c.no*c.no-dot(k,k));
 return [0,1].map(mode=>{
  const p=[...k,mode?qe:qo],dp=[0,0,mode?dqe:0],eo=cross(a,p),deo=add(cross(da,p),cross(a,dp));
  if(O.norm(eo)/O.norm(p)<1e-5)throw Error('光学軸付近で縮退');
  let E=eo,dE=deo;
  if(mode){const d=cross(p,eo),dd=add(cross(dp,eo),cross(p,deo)),q=dot(a,d),dq=dot(da,d)+dot(a,dd),u=1/c.ne**2-1/c.no**2;E=add(mul(d,1/c.no**2),mul(a,u*q));dE=add(mul(dd,1/c.no**2),mul(add(mul(da,q),mul(a,dq)),u));}
  const H=cross(p,E),dH=add(cross(dp,E),cross(p,dE)),flux=sign*.5*cross(E,H)[2],dflux=sign*.5*add(cross(dE,H),cross(E,dH))[2];
  if(!(flux>1e-15))throw Error('前方2モードの流束条件外');
  const norm=1/Math.sqrt(flux),corr=-.5*dflux/flux;
  return {p,E:mul(E,norm),H:mul(H,norm),dE:mul(add(dE,mul(E,corr)),norm),dH:mul(add(dH,mul(H,corr)),norm)};
 });
}
function coefficients(z,k,c,sign){if(c.material!=='heliconical')return F.coherentGeneral.coefficients(z,k,c,sign);const f=frame(z,k,c,sign),der=f.map(x=>({E:x.dE,H:x.dH}));return {g:.5*(F.modal.inner(f[1],der[0],sign)-F.modal.inner(f[0],der[1],sign)),delta:Math.PI*c.lengthUnitUm/(c.wavelengthNm*.001)*(f[0].p[2]-f[1].p[2])};}
F.fastHelix={frame,coefficients};
})(globalThis.Optics,globalThis.Optics.polarization);
