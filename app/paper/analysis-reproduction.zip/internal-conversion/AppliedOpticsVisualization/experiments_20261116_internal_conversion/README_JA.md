# 媒質内モード結合の比較を再実行する手順

このフォルダーは2026年11月16日の比較用スナップショットです。公開アプリと論文用エンジンは変更していません。結果と適用範囲は `REPORT_JA.md` を参照してください。

## 実行環境

Node.js 22とPython 3、NumPy、Matplotlibを使用します。Node.js側に追加パッケージは不要です。Python側は `pip install numpy matplotlib` で必要なライブラリーを導入できます。ZIPを展開したルートを作業ディレクトリーとし、以下の相対パスを保ってください。

## 再実行

```sh
node AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/validate-fast.cjs
node AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/validate-su2.cjs
node AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/radial-audit.cjs
python AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/independent-maxwell.py
node AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/geometry-control.cjs
node AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/grid-samples.cjs
node AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/grid-narrow.cjs
node AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/central-rays.cjs
node AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/make-mask.cjs
node AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/render-phase.cjs
python AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/analyze.py
node AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/check-critical.cjs
python AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/analyze.py
python AppliedOpticsVisualization/experiments_20261116_internal_conversion/scripts/fig-radial.py
```

全画素計算には時間がかかります。保存済みデータから図と集計を再生成する場合は、最後の `analyze.py` と `fig-radial.py` だけを実行してください。Node.jsとPythonの並列実行は必須ではありません。

`render-phase.cjs` は既定で16ワーカーを使用します。環境変数 `COUPLING_WORKERS` で変更できます。`COUPLING_RUNS` に `[["heliconical",1000]]` または `[["heliconical",50]]` を設定すると、一方の実寸条件だけを計算できます。単位はµmです。出力ファイルは上書きされます。保存済み成果を保持する場合は、ZIPを別のフォルダーへ展開して実行してください。

## データの意味

- `configs/cases.json` は論文用の11条件の保存値です。各実験スクリプト内で、CPU、解像度、結合モデル、実寸、光束幅を明示的に上書きします。
- `*-off.f64` と `*-on.f64` は256×256×3の線形RGB値です。float64、little endian、行優先、RGB順です。
- `*-diagnostics.f64` は同じ画素配置で、計算失敗の重み、打切りの重み、結合計算の条件外となり独立モード伝播へ戻った区間の累積重みの順です。最後の量は区間ごとの累積値であり、像の誤差上限ではありません。
- `lens-mask.u8` はレンズを通るカメラ方向のマスクです。8 bit整数、256×256です。
- `grid-samples.json` と `grid-narrow.json` は画角全体の代表方向の比較です。レンズ外の方向も保存しています。
- `central-rays.json` は中央方向の直接透過成分の背景到達点と重みの集計です。
- `independent-maxwell.json` は中央方向に対応する厚さ2Lの平板の独立Maxwell計算です。非球面レンズ全体のMaxwell像ではありません。
- `radial-audit.json` は球対称な媒質内部の偏光分離と保存量の確認です。未対応の分岐スイッチをONにして比較した結果ではありません。
- `critical-pixel-checks.json` は差の大きい画素などについて、結合だけをゼロにした対照計算と位相許容誤差を厳しくした計算を記録します。
- `source-provenance.json` は参照した原稿と元実装のハッシュです。`MANIFEST_SHA256.json` はこの配布用スナップショットのハッシュです。

全画像には元の複素行列CF4積分を使用しました。`fast-helix.js` は局所固有場とその微分を解析的に評価します。代表方向と中央光線には、同一CF4積分をSU(2)の実数演算で表現した `fast-phase.js` を使用しました。元の複素行列計算との比較は `su2-validation.json` に保存しています。

比較用の非球面レンズ対応は `coherent-finite.js` に限って追加しました。媒質内部の後進波との結合、回折、別経路間の干渉は含めません。片方のモードが先に界面へ到達した後、他方が自身の界面へ到達するまでの残り区間は独立モード伝播です。したがって、これらの画像は追加近似に対する感度を調べる資料です。
