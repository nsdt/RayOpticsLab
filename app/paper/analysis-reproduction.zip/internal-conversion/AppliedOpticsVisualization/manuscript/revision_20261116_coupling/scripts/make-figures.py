from pathlib import Path
import sys,json,math
R=Path(__file__).resolve().parents[1];P=R.parent;ROOT=P.parents[1];E=P.parent/'experiments_20261116_internal_conversion';sys.path.insert(0,str(ROOT/'tmp/ao20261112-python'))
(P/'figures').mkdir(parents=True,exist_ok=True);(R/'review').mkdir(parents=True,exist_ok=True)
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'axes.titlesize':9,'axes.labelsize':8.5,'legend.fontsize':7.5,'pdf.fonttype':42})
display=lambda a:np.clip(np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055),0,1)
fig,axs=plt.subplots(2,3,figsize=(6.65,4.55));fig.subplots_adjust(left=.025,right=.94,bottom=.02,top=.94,wspace=.13,hspace=.16)
for row,L in enumerate([1000,50]):
 load=lambda tag:np.fromfile(E/f'data/heliconical-L{L}-{tag}.f64','<f8').reshape(256,256,3)
 off,on,diag=[load(t)for t in ['off','on','diagnostics']];diff=np.max(abs(on-off),axis=2)
 for col,a in enumerate([off,on]):axs[row,col].imshow(display(a),interpolation='nearest')
 cm=plt.get_cmap('magma').copy();cm.set_bad('#bbbbbb');m=axs[row,2].imshow(np.ma.masked_where(diag[:,:,0]>0,diff),cmap=cm,vmin=0,vmax=float(diff.max()),interpolation='nearest');cb=fig.colorbar(m,ax=axs[row,2],fraction=.047,pad=.025)
 cb.formatter=ScalarFormatter(useMathText=True);cb.formatter.set_powerlimits((-3,3));cb.update_ticks();cb.ax.tick_params(labelsize=7)
 if L==1000:
  cb.ax.yaxis.get_offset_text().set_visible(False);cb.ax.text(.5,-.075,r'$\times10^{-4}$',transform=cb.ax.transAxes,ha='center',va='top',fontsize=7)
 for ax in axs[row]:ax.set_xticks([]);ax.set_yticks([]);ax.spines[['left','right','top','bottom']].set_visible(False)
 axs[row,0].set_ylabel(f'$L={L/1000:g}$ mm',fontsize=9,labelpad=2)
for ax,t in zip(axs[0],['Independent modes','Coupled packets','Absolute difference']):ax.set_title(t,pad=5)
for ext in ['pdf','png']:fig.savefig((P/'figures'if ext=='pdf'else R/'review')/f'internal-coupling-images.{ext}',dpi=240,bbox_inches='tight',pad_inches=.025)
plt.close(fig)
maxwell=json.loads((E/'data/independent-maxwell.json').read_text());central=json.loads((E/'data/central-rays.json').read_text())
fig,axs=plt.subplots(1,2,figsize=(6.65,2.65));fig.subplots_adjust(left=.105,right=.98,bottom=.19,top=.88,wspace=.38)
for L,color in [(1000,'#147eb3'),(50,'#d06020')]:
 rows=[r for r in maxwell if r['L_um']==L and r['omega']!=0];axs[0].semilogy([r['omega']for r in rows],[max(m['maxConversion']for m in r['modes'])for r in rows],'o-',ms=3.5,lw=1,color=color,label=f'$L={L/1000:g}$ mm')
 rows=sorted([r for r in central if r['L']==L and r['beamRadiusRatio']==.02],key=lambda r:r['omega']);axs[1].plot([r['omega']for r in rows],[r['after']['rmsRadius']for r in rows],'o-',ms=3.5,lw=1,color=color,label=f'$L={L/1000:g}$ mm')
rows=sorted([r for r in central if r['L']==1000 and r['beamRadiusRatio']==.02],key=lambda r:r['omega']);axs[1].plot([r['omega']for r in rows],[r['before']['rmsRadius']for r in rows],'k--',lw=1,label='Independent modes')
for ax in axs:
 ax.set_xlabel(r'Twist rate $\omega$');ax.set_xticks([0,1,2.5,math.pi,4,6],['0','1','2.5',r'$\pi$','4','6']);ax.grid(alpha=.17);ax.legend(frameon=False)
axs[0].set(title='(a) Normal-incidence Maxwell calculation',ylabel='Maximum converted power fraction')
axs[1].set(title='(b) Central direct paths',ylabel=r'RMS background radius / $L$')
for ext in ['pdf','png']:fig.savefig((P/'figures'if ext=='pdf'else R/'review')/f'internal-coupling-central.{ext}',dpi=240,bbox_inches='tight',pad_inches=.025)
print('Generated two supplement figures from archived data.')
