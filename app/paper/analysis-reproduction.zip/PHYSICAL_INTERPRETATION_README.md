# Reproduction archive, 16 November 2026

All 80 material/camera configurations and the CPU/GPU calculation algorithms are
unchanged. The article has 12 pages and Supplement 1 has 22 pages. The 15 five-case
trajectory figures share axial labels at the bottom and transverse tick labels
at the rightmost column. Each legend is one row with only P0-P4 and internal
reflection. Modal line styles are explained in the captions.
P0-P4 identify fixed camera directions. The original +/U/D/L/R target markings
remain in the camera images. The hollow overlay circles indicate camera samples.

From the extracted root, regenerate supplemental Figures S2-S16, S18-S21 and S23 with Python,
NumPy and Matplotlib:

    python AppliedOpticsVisualization/manuscript/revision_20261116_equations/scripts/compact-atlas.py
    python AppliedOpticsVisualization/manuscript/revision_20261116_equations/scripts/remaining-atlases.py

All arrays, path records and helper scripts needed by this command are included.
No camera rays are recalculated by this layout command. The source arrays retain
their original 256 or 384 pixel side length. PNGs and vector PDFs are written to
AppliedOpticsVisualization/manuscript/figures/.

See PHYSICAL_COMPARISONS_README.md for the exact omega = pi image, reciprocal
radiance decomposition, and associated trajectory calculations. The earlier
atlas README and historical numerical records are retained with their dates.
