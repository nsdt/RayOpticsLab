# Camera trajectory atlas, 15 November 2026

This directory contains the unchanged 79 camera-image arrays and physical
configurations used for the manuscript, with new representative trajectories.
The article remains 11 pages; Supplement 1 is 28 pages.

From this directory, run with Node.js and Python (NumPy and Matplotlib):

    node AppliedOpticsVisualization/experiments_20261115_trajectory_gallery/scripts/trace-gallery.cjs
    node AppliedOpticsVisualization/experiments_20261115_trajectory_gallery/scripts/validate.cjs
    python AppliedOpticsVisualization/experiments_20261115_trajectory_gallery/scripts/figures.py

The exact instrumented CPU engine is included under RayOpticsLab/paper/engine/.
No GPU is required for the trajectory records. Original images are retained as
little-endian float64 arrays. The plotting program applies the same sRGB encoding
and displays the original image arrays without recalculating image pixels.
Output PDF/PNG figures are written under AppliedOpticsVisualization/manuscript/figures/.

P0--P4 are fixed camera directions: image-width-normalized coordinates
(0,0), (0,0.25), (0,-0.25), (-0.25,0), (0.25,0), measured rightward/upward.
The input direction is shared by internal modes. Coincident paths from the two
incident polarization states are merged, and the retained path of largest
weight is selected for each initial internal mode. A single coincident path is
displayed for isotropic and transformation media. Internal reflections are
marked by squares. Ordinary paths are solid, extraordinary paths dashed.
The exterior segment after exit retains the last internal mode's line style;
there is no exterior birefringence. Entrance reflection is dotted.
The transverse view is cropped to [-1.55 L, 1.55 L].

These samples differ from the independently solved landmark connections in
article Fig. 4 and supplemental Fig. S17. Each of those connections reaches the
same background landmark, generally from a different initial camera direction.
Spectral trajectory examples use 450, 550 and 650 nm, whereas the retained
spectral image arrays were integrated over 128 bins.

validation.json records 79 cases, 415 direction/wavelength pairs and 577 paths.
All runs have zero failed weight. The central heliconical endpoints agree with
the sin(omega)/omega displacement relation within 3.8e-12 L. These checks concern
the illustrative path records and are not an independent validation of the engine.

The captured configurations retain their metadata at the start of this revision.
Their case identifiers and physical parameters match the updated browser catalog;
current supplemental figure numbers are S2--S16 and S18--S21.
