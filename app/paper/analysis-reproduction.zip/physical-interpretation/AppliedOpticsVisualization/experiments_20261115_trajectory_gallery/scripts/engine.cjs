const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'../../..'), eng=path.join(root,'RayOpticsLab/paper/engine');
const vm=require('vm'),context=vm.createContext({console});
for(const n of ['polynomial','landmark-target','asphere','literature-media','optics','rkf45','analytical','schur','approximate','homogeneous','grin','branching','polarization','data/spectral/cie-visible','data/spectral/schott-visible','spectral'])vm.runInContext(fs.readFileSync(path.join(eng,n+'.js'),'utf8'),context,{filename:n+'.js'});
const O=context.Optics,Spectral=context.Spectral;
const F=O.polarization;
function camera(u,v,c){const {eye,forward,right,up}=O.cameraFrame(c),s=8*Math.tan(c.fov*Math.PI/360),off=O.add(O.mul(right,u*s),O.mul(up,v*s));return {o:eye,d:O.unit(O.add(O.mul(forward,4),off))};}
module.exports={O,F,camera,Spectral};
if(require.main===module){const a=JSON.parse(fs.readFileSync(path.join(__dirname,'../configs/experiments.json'))),s=a.cases.find(c=>c.id==='reciprocal'),c={...s.config,paperCapture:true};const ray=camera(.25,0,c),r=F.trace(ray.o,ray.d,c);console.log(JSON.stringify({keys:Object.keys(r),stats:{status:r.status,leaves:r.leaves},leaves:r.paperLeaves?.slice(0,3).map(l=>({...l,segments:l.segments.map(s=>({mode:s.mode,n:s.states.length,first:s.states[0],last:s.states.at(-1)}))}))},null,2));}
