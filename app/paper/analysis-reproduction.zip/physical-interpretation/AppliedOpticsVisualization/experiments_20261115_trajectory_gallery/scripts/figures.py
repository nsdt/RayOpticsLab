from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[3]; E=ROOT/'AppliedOpticsVisualization/experiments_20261115_trajectory_gallery';P=ROOT/'AppliedOpticsVisualization/manuscript';R=P/'revision_20261115_trajectory_gallery'
for directory in [P/'figures',R/'review']: directory.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'tmp/ao20261112-python'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':8.5,'axes.labelsize':8,'legend.fontsize':8,'pdf.fonttype':42})
cat=json.loads((E/'configs/experiments.json').read_text());rawdirs=[ROOT/'AppliedOpticsVisualization/experiments_20260928_isotropic_columns/data',ROOT/'AppliedOpticsVisualization/experiments_20260927_revision/data'];colors={'P0':'#292929','P1':'#1260c4','P2':'#cf8500','P3':'#00854a','P4':'#9c359d'};layout={}
rr=np.linspace(-1,1,401);zz=1-rr*rr/(.6+np.sqrt(.36+.69*rr*rr))
def data(s):return json.loads((E/'data'/(s['id']+'.json')).read_text())
def source(s):
 name=s['id']+'-n'+str(s['config']['resolution'])+'.linear.f64' if s['kind']=='mono' else s['group'].replace('-dispersion','')+('-spectral-final.f64' if s['kind']=='spectral' else '-achromatic-final.f64')
 return next(d/name for d in rawdirs if (d/name).exists())
def picture(ax,s,label):
 p=source(s);n=s['config']['resolution'];a=np.fromfile(p,'<f8').reshape(n,n,3);a=np.clip(np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055),0,1);ax.imshow(a,interpolation='nearest');ax.set_xticks([]);ax.set_yticks([]);ax.set_title(label,pad=2)
 for r in data(s)['samples'][:5]:
  x=(.5+r['u'])*n-.5;y=(.5-r['v'])*n-.5;col=colors[r['sample']];ax.plot(x,y,'o',ms=3.7,mfc='white',mec=col,mew=1);ax.annotate(r['sample'],(x,y),xytext=(3,-6),textcoords='offset points',fontsize=6.5,color=col,bbox={'fc':'white','ec':'none','alpha':.85,'pad':.2})
 return {'id':s['id'],'inputSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'input':p.relative_to(ROOT).as_posix()}
def axes_setup(ax,coord,title):
 ax.fill_betweenx(rr,-1,zz,color='#eef1f4');ax.plot(zz,rr,color='#596775',lw=.55);ax.plot([-1,-1],[-1,1],color='#596775',lw=.55)
 ax.plot([-1,zz[0]],[-1,-1],color='#596775',lw=.55);ax.plot([-1,zz[-1]],[1,1],color='#596775',lw=.55)
 ax.axvline(-3,color='#88929c',lw=.5,ls=':');ax.plot(4,0,'o',color='black',ms=2)
 ax.set(xlim=(-3.15,4.15),ylim=(-1.55,1.55),xticks=[-3,-1,1,4],yticks=[-1,0,1],xlabel='$z/L$',ylabel='$x/L$' if coord==0 else '$y/L$',title=title);ax.grid(alpha=.12);ax.tick_params(labelsize=7,pad=1)
def trajectory(ax,rec,coord):
 col=colors[rec['sample']];entry=np.asarray(rec['entry']);cam=np.asarray(rec['camera']['o']);ax.plot([cam[2],entry[2]],[cam[coord],entry[coord]],color=col,lw=.7,alpha=.7)
 if not rec['paths']:ax.plot(entry[2],entry[coord],'x',color=col,ms=4);return
 for l in rec['paths']:
  if not l['segments']:
   o=np.array(l['events'][0]['position']);q=o+3*np.array(l['d']);ax.plot([o[2],q[2]],[o[coord],q[coord]],':',color=col,lw=1.1);ax.annotate('',xy=(q[2],q[coord]),xytext=(o[2],o[coord]),arrowprops={'arrowstyle':'->','color':col,'lw':.6});continue
  internal_events=[e for e in l['events'] if e['insideBefore']]
  for j,seg in enumerate(l['segments']):
   pts=np.asarray(seg['states'])[:,:3];start=entry if j==0 else np.array(internal_events[j-1]['position']);pts=np.vstack([start,pts]);ax.plot(pts[:,2],pts[:,coord],'-' if seg['mode']==0 else '--',color=col,lw=1)
  for e in internal_events:
   if e['reflection']:ax.plot(e['position'][2],e['position'][coord],'s',color=col,ms=3,mfc='white',mew=.8)
  o=np.asarray(l['events'][-1]['position']);q=np.asarray(l['q']) if l['q'] is not None else o+3*np.asarray(l['d']);style='-' if l['segments'][-1]['mode']==0 else '--';ax.plot([o[2],q[2]],[o[coord],q[coord]],style,color=col,lw=1)
  if l['q'] is not None:ax.plot(q[2],q[coord],'o',color=col,ms=2)
  else:ax.annotate('',xy=(q[2],q[coord]),xytext=(o[2],o[coord]),arrowprops={'arrowstyle':'->','color':col,'lw':.6})
def legend(fig):
 hs=[Line2D([],[],color=c,lw=1.5,label=k)for k,c in colors.items()]+[Line2D([],[],color='k',ls='-',label='Ordinary / coincident'),Line2D([],[],color='k',ls='--',label='Extraordinary'),Line2D([],[],color='k',marker='s',mfc='white',ls='',label='Internal reflection')]
 fig.legend(handles=hs,loc='lower center',ncol=4,frameon=False,bbox_to_anchor=(.5,.004),handlelength=2,columnspacing=1.1)
def save(fig,name,recs):
 for ext in ['png','pdf']:fig.savefig(P/'figures'/(name+'.'+ext),dpi=230,bbox_inches='tight',pad_inches=.025)
 plt.close(fig);layout[name]=recs
for group in [g['id']for g in cat['groups']if not g['id'].endswith('-dispersion')]:
 specs=[s for s in cat['cases']if s['group']==group];fig,axs=plt.subplots(5,3,figsize=(7.2,8.15),gridspec_kw={'width_ratios':[1,1.35,1.35]});fig.subplots_adjust(left=.02,right=.992,top=.97,bottom=.085,hspace=.62,wspace=.34);inputs=[]
 for k,s in enumerate(specs):
  label=s['label'];label=label if '$' in label else '$'+label+'$';label=label.replace(', $','\n$') if group=='hyperbolic' else label
  inputs.append(picture(axs[k,0],s,'('+chr(97+k)+') '+label))
  for j,coord in enumerate([0,1],1):
   axes_setup(axs[k,j],coord,'$xz$ projection' if j==1 and k==0 else '$yz$ projection' if j==2 and k==0 else '')
   for rec in data(s)['samples']:trajectory(axs[k,j],rec,coord)
 legend(fig);save(fig,'atlas-'+group,inputs);print(group)
for s in [s for s in cat['cases']if s['kind']!='mono']:
 rows=data(s)['samples']
 if s['kind']=='constant':
  fig,axs=plt.subplots(1,3,figsize=(7.2,2.5),gridspec_kw={'width_ratios':[1,1.35,1.35]});fig.subplots_adjust(left=.02,right=.992,top=.9,bottom=.28,wspace=.34);ins=[picture(axs[0],s,'(a) $B=0$' if s['group'].startswith('iso-') else '(a) $B_o=B_e=0$')]
  for j,coord in enumerate([0,1],1):
   axes_setup(axs[j],coord,'$xz$ projection'if j==1 else '$yz$ projection')
   for rec in rows:trajectory(axs[j],rec,coord)
 else:
  fig=plt.figure(figsize=(7.2,4.6));gs=fig.add_gridspec(2,4,width_ratios=[1.3,1,1,1],left=.02,right=.99,top=.94,bottom=.18,wspace=.5,hspace=.52);ins=[picture(fig.add_subplot(gs[:,0]),s,'(a) Dispersive image')]
  for j,nm in enumerate([450,550,650],1):
   for k,coord in enumerate([0,1]):
    ax=fig.add_subplot(gs[k,j]);axes_setup(ax,coord,str(nm)+' nm'if k==0 else '')
    for rec in rows:
     if rec['wavelength']==nm:trajectory(ax,rec,coord)
 legend(fig);save(fig,'atlas-'+s['id'],ins)
(R/'review/atlas-layout.json').write_text(json.dumps(layout,indent=2));print('Atlas images:',sum(len(v)for v in layout.values()))
