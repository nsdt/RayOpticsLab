const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const enginePath=path.join(__dirname,'engine.cjs');
// A local CommonJS loader avoids UNC parent-package probing in Windows Node.
const Module=require('node:module'),em=new Module(enginePath,module);em.filename=enginePath;em.paths=module.paths;em._compile(fs.readFileSync(enginePath,'utf8'),enginePath);
const {O,F,camera,Spectral}=em.exports;
const root=path.resolve(__dirname,'..'),catalog=JSON.parse(fs.readFileSync(path.join(root,'configs/experiments.json'))),records=[];
const samples=[['P0',0,0],['P1',0,.25],['P2',0,-.25],['P3',-.25,0],['P4',.25,0]];
const scalar=new Set(['isotropic','axialSquared','radialSquared','sphericalSquared','shear','sphericalTransform','cylindricalTransform']);
function signature(l){return JSON.stringify(l.events.map(e=>[e.mode,e.reflection,...e.position.map(x=>+x.toFixed(8))]));}
for(const spec of catalog.cases){
 const rows=[],wavelengths=spec.kind==='spectral'?[450,550,650]:[550],start=Date.now();
 for(const nm of wavelengths){const c0=spec.kind==='spectral'?Spectral.sampleConfig(spec.config,nm):spec.config,c={...c0,paperCapture:true};
  for(const [id,u,v] of samples){const ray=camera(u,v,c),entry=O.hit(ray.o,ray.d,c.shape),r=F.trace(ray.o,ray.d,c),merged=new Map();
   for(const l of r.paperLeaves||[]){const key=signature(l);if(merged.has(key))merged.get(key).weight+=l.weight;else merged.set(key,JSON.parse(JSON.stringify(l)));}
   const all=[...merged.values()],paths=[],modes=scalar.has(c.material)?[0]:['hyperbolic','eng2013Magnetic'].includes(c.material)?[1]:[0,1];
   for(const mode of modes){const leaves=all.filter(l=>l.segments.length&&l.segments[0].mode===mode).sort((a,b)=>b.weight-a.weight);if(leaves.length)paths.push({...leaves[0],initialMode:mode,selection:'largest summed weight among retained paths for this initial internal mode',candidateCount:leaves.length});}
   if(!paths.length){const l=all.filter(l=>!l.segments.length).sort((a,b)=>b.weight-a.weight)[0];if(l)paths.push({...l,initialMode:null,selection:'entrance reflection; no retained internal path'});}
   const rec={sample:id,u,v,wavelength:nm,camera:ray,entry,paths,stats:{status:r.status,failedWeight:r.failedWeight,unavailableWeight:r.unavailableWeight,dropped:r.dropped,unresolvedWeight:r.unresolvedWeight,weightSum:r.weightSum,leaves:r.leaves}};
   rows.push(rec);
  }
 }
 const record={id:spec.id,group:spec.group,kind:spec.kind,label:spec.label,config:spec.config,samples:rows,elapsedMs:Date.now()-start};records.push(record);
 fs.writeFileSync(path.join(root,'data',spec.id+'.json'),JSON.stringify(record));
 console.log(spec.id,rows.length,'rays',rows.reduce((n,r)=>n+r.paths.length,0),'paths',record.elapsedMs,'ms');
}
fs.writeFileSync(path.join(root,'data/manifest.json'),JSON.stringify({protocol:'Five fixed camera directions; merge coincident paths from the incoherent input states; select the largest retained path weight for each initial internal mode. Segment line style follows the local internal mode.',samples,wavelengths:[450,550,650],catalogSHA256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'configs/experiments.json'))).digest('hex'),cases:records.map(r=>({id:r.id,kind:r.kind,samples:r.samples.length,elapsedMs:r.elapsedMs}))},null,2));
