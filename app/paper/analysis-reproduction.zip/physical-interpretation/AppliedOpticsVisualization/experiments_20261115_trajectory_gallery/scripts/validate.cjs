const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const p=path.join(__dirname,'engine.cjs'),m=new Module(p,module);m.filename=p;m.paths=module.paths;m._compile(fs.readFileSync(p,'utf8'),p);const {O,Spectral}=m.exports;
const root=path.resolve(__dirname,'..'),cat=JSON.parse(fs.readFileSync(path.join(root,'configs/experiments.json'))),report={cases:0,samples:0,paths:0,states:0,maxHamiltonianResidual:0,maxBoundaryResidual:0,maxEntranceDifference:0,maxFailedWeight:0,helical:[],missingModes:[]};
const records=cat.cases.map(s=>JSON.parse(fs.readFileSync(path.join(root,'data',s.id+'.json'))));
for(const a of records){report.cases++;const source=cat.cases.find(s=>s.id===a.id);assert.deepEqual(a.config,source.config);
 for(const r of a.samples){report.samples++;assert.equal(r.stats.status,'ok');report.maxFailedWeight=Math.max(report.maxFailedWeight,r.stats.failedWeight);const c=a.kind==='spectral'?Spectral.sampleConfig(a.config,r.wavelength):a.config;
  if(['common','quadratic','heliconical','radialUniaxial','uniaxial'].includes(c.material)&&r.paths.length<2)report.missingModes.push({id:a.id,sample:r.sample,nm:r.wavelength,modes:r.paths.map(p=>p.initialMode)});
  for(const l of r.paths){report.paths++;assert(l.weight>=0);for(const e of l.events){assert(e.position.every(Number.isFinite));report.maxBoundaryResidual=Math.max(report.maxBoundaryResidual,Math.abs(O.sdf(e.position,c.shape)));}report.maxEntranceDifference=Math.max(report.maxEntranceDifference,Math.hypot(...l.events[0].position.map((v,i)=>v-r.entry[i])));
   for(const s of l.segments)for(const q of s.states){report.states++;assert(q.every(Number.isFinite));const h=Math.abs(O.H(q.slice(0,3),q.slice(3),c,s.mode)-.5);assert(Number.isFinite(h));report.maxHamiltonianResidual=Math.max(report.maxHamiltonianResidual,h);}
   if(l.q){assert(l.q.every(Number.isFinite));assert(Math.abs(l.q[2]+3)<1e-8);}
  }
 }
}
const hel=records.filter(r=>r.group==='heliconical'),center=a=>a.samples.find(s=>s.sample==='P0').paths.find(l=>l.initialMode===1).q.slice(0,2),b=center(hel.find(a=>a.config.twist===0));
for(const a of hel){const w=a.config.twist,q=center(a),factor=w===0?1:Math.sin(w)/w,expected=b.map(v=>v*factor);report.helical.push({omega:w,background:q,factor,errorL:Math.hypot(...q.map((v,i)=>v-expected[i]))});}
assert.equal(report.cases,79);assert.equal(report.samples,415);assert.equal(report.maxFailedWeight,0);assert(report.maxBoundaryResidual<1e-8);assert(report.maxEntranceDifference<1e-10);assert(report.maxHamiltonianResidual<1e-6);assert(report.helical.every(r=>r.errorL<1e-6));
fs.writeFileSync(path.join(root,'data/validation.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
