const fs=require('node:fs'),path=require('node:path'),{O,F,P}=require('./engine.cjs');
const root=path.resolve(__dirname,'..'),base=path.resolve(__dirname,'../../experiments_20261115_trajectory_gallery/data');
const spec=JSON.parse(fs.readFileSync(path.join(root,'configs/heliconical-pi.json'))),records=[];
for(const[id,u,v]of[['P0',0,0],['P1',0,.25],['P2',0,-.25],['P3',-.25,0],['P4',.25,0]]){
 const ray=P.camera((u+.5)*256-.5,(.5-v)*256-.5,256,spec.config),entry=O.hit(ray.o,ray.d,spec.config.shape),r=F.trace(ray.o,ray.d,{...spec.config,paperCapture:true}),paths=[];
 const map=new Map();for(const l of r.paperLeaves||[]){const key=JSON.stringify(l.events.map(e=>[e.mode,e.reflection,...e.position.map(v=>+v.toFixed(8))]));if(map.has(key))map.get(key).weight+=l.weight;else map.set(key,JSON.parse(JSON.stringify(l)));}
 for(const mode of[0,1]){const a=[...map.values()].filter(l=>l.segments.length&&l.segments[0].mode===mode).sort((a,b)=>b.weight-a.weight);if(a.length)paths.push({...a[0],initialMode:mode});}
 records.push({sample:id,u,v,camera:ray,entry,paths,status:r.status,failedWeight:r.failedWeight});
}
fs.writeFileSync(path.join(root,'data/heliconical-pi-rays.json'),JSON.stringify({id:spec.id,config:spec.config,samples:records},null,2));
const p0=records[0],e=p0.paths.find(l=>l.initialMode===1),norm=Math.hypot(...e.q.slice(0,2));console.log('pi center background displacement',norm,'L');
// Confirm that the retained reflection arrays equal current-engine accumulation at sampled pixels.
const old=path.resolve(__dirname,'../../experiments_20260927_revision/data'),catalog=JSON.parse(fs.readFileSync(path.resolve(__dirname,'../../../RayOpticsLab/paper/experiments.json'))),checks=[];
for(const id of['reciprocal','reciprocal-v4']){const c=catalog.cases.find(s=>s.id===id).config;const load=suffix=>{const b=fs.readFileSync(path.join(old,id+'-n256.'+suffix+'.f64'));return new Float64Array(b.buffer,b.byteOffset,b.byteLength/8);};const total=load('linear'),ref=load('any_reflection');let max=0,n=0;for(let y=44;y<224;y+=28)for(let x=44;x<224;x+=28){const ray=P.camera(x,y,256,c);if(!O.hit(ray.o,ray.d,c.shape))continue;const r=P.pixel(x,y,256,{...c,paperChannels:true},P.palette(c));if(r.status!=='ok')throw Error(r.message);for(let j=0;j<3;j++){max=Math.max(max,Math.abs(r.linear[j]-total[(y*256+x)*3+j]),Math.abs((r.paperChannels?.any_reflection?.[j]||0)-ref[(y*256+x)*3+j]));}n++;}if(max>1e-10)throw Error('channel mismatch '+max);checks.push({id,pixels:n,maxChannelDifference:max});}
const summary={piCenterDisplacementL:norm,piRays:records.length,checks};fs.writeFileSync(path.join(root,'data/probe-checks.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary));
