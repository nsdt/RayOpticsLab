const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'../../..'),eng=path.join(root,'RayOpticsLab/paper/engine'),O=require(path.join(eng,'optics.js'));
for(const n of ['analytical','schur','approximate','homogeneous','grin','branching','polarization','data/spectral/cie-visible','data/spectral/schott-visible','spectral'])require(path.join(eng,n+'.js'));
require(path.join(root,'RayOpticsLab/paper/protocol.js'));
module.exports={O,F:O.polarization,P:globalThis.PaperProtocol};
