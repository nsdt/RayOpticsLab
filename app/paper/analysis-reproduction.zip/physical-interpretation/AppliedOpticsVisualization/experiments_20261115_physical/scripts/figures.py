from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[3];P=ROOT/'AppliedOpticsVisualization/manuscript';E=ROOT/'AppliedOpticsVisualization/experiments_20261115_physical';A=ROOT/'AppliedOpticsVisualization/experiments_20261115_trajectory_gallery';OLD=ROOT/'AppliedOpticsVisualization/experiments_20260927_revision/data';R=P/'revision_20261115_physical'
sys.path.insert(0,str(ROOT/'tmp/ao20261112-python'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
for directory in [P/'figures',R/'review']: directory.mkdir(parents=True,exist_ok=True)
src=(A/'scripts/figures.py').read_text()
h={'__file__':str(A/'scripts/figures.py')};exec(compile(src[:src.index('for group in [')],str(A/'scripts/figures.py'),'exec'),h)
plt.rcParams.update({'font.size':8.5,'axes.titlesize':9,'axes.labelsize':8.5,'legend.fontsize':8,'pdf.fonttype':42})
manifest={}
def display(a):return np.clip(np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055),0,1)
def raw(id):
 p=E/'data'/f'{id}-n256.linear.f64' if id=='heliconical-pi' else OLD/f'{id}-n256.linear.f64';return np.fromfile(p,'<f8').reshape(256,256,3)
def picture(ax,a,title):ax.imshow(display(a),interpolation='nearest');ax.set(xticks=[],yticks=[],title=title)
def save(fig,name):
 for ext in ['pdf','png']:fig.savefig(P/'figures'/f'{name}.{ext}',dpi=260,bbox_inches='tight',pad_inches=.03)
 plt.close(fig);manifest[name]=hashlib.sha256((P/'figures'/f'{name}.pdf').read_bytes()).hexdigest()
# Same-landmark connections, one radial row retained in the article.
s=(P/'revision_20261115_trajectory_gallery/scripts/restyle-correspondence.py').read_text();s=s[:s.index("fig,axes=plt.subplots(3,3")];s=s.replace("plt.subplots(2,3,figsize=(7.3,4.6),layout='constrained')","plt.subplots(1,3,figsize=(7.3,2.35),layout='constrained',squeeze=False)").replace("['reciprocal','radial-axis']","['radial-axis']").replace("['(a) $g=0.25$','(d) $R_r=7$']","['(a) $R_r=7$']").replace("'compact-landmark-rays'","'physical-radial'")
exec(compile(s,'radial-plot','exec'),{'__file__':str(P/'revision_20261115_physical/scripts/unused.py')})
# Heliconical comparison and central-ray explanation.
ids=['heliconical-v1','heliconical-pi','heliconical-v4'];ws=[0,np.pi,6];cols=['#222222','#0072b2','#c87500'];records=[]
fig,ax=plt.subplots(2,3,figsize=(7.2,4.5),layout='constrained')
for j,(id,w,col)in enumerate(zip(ids,ws,cols)):
 picture(ax[0,j],raw(id),'('+chr(97+j)+') $\\omega='+('\\pi'if id=='heliconical-pi'else str(w))+'$');ax[0,j].plot(127.5,127.5,'o',ms=3,mfc='white',mec='black')
 data=json.loads((E/'data/heliconical-pi-rays.json').read_text())if id=='heliconical-pi'else json.loads((A/'data'/f'{id}.json').read_text());r=data['samples'][0];l=next(x for x in r['paths']if x['initialMode']==1);pts=np.array(l['segments'][0]['states']);records.append((w,l['q'][:2]))
 for k,coord in enumerate([0,1]):ax[1,k].plot(pts[:,2],pts[:,coord],'--',color=col,lw=1.25,label='$\\omega='+('\\pi'if id=='heliconical-pi'else str(w))+'$')
for k,coord in enumerate([0,1]):
 a=ax[1,k];a.axhline(0,color='#888',lw=.7,label='Ordinary');a.set(xlabel='$z/L$',ylabel='$x/L$'if coord==0 else'$y/L$',title='('+chr(100+k)+') Central internal paths',xlim=(-1.04,1.04));a.grid(alpha=.15)
ax[1,0].legend(frameon=False,ncol=2,fontsize=7)
w=np.linspace(0,6.4,400);ax[1,2].plot(w,np.sinc(w/np.pi),color='black',lw=1);vals=json.loads((A/'data/validation.json').read_text())['helical'];w0=np.array(next(x['background']for x in vals if x['omega']==0));pairs=[(x['omega'],np.dot(x['background'],w0)/np.dot(w0,w0))for x in vals]+[(np.pi,np.dot(records[1][1],w0)/np.dot(w0,w0))];ax[1,2].plot(*np.array(pairs).T,'o',mfc='white',mec='#0072b2',ms=4);ax[1,2].set(xlabel='$\\omega$',ylabel='Signed displacement ratio',title='(f) Central exit displacement',xticks=[0,np.pi,6],xticklabels=['0','$\\pi$','6'],ylim=(-.3,1.05));ax[1,2].axhline(0,color='#bbb',lw=.5);ax[1,2].grid(alpha=.15);save(fig,'physical-heliconical')
# Complete pi atlas row for the supplement.
data=json.loads((E/'data/heliconical-pi-rays.json').read_text());fig,ax=plt.subplots(1,3,figsize=(7.2,2.55),gridspec_kw={'width_ratios':[1,1.3,1.3]});fig.subplots_adjust(left=.02,right=.99,top=.9,bottom=.3,wspace=.35);picture(ax[0],raw('heliconical-pi'),'(a) $\\omega=\\pi$')
for rec in data['samples']:
 x=(.5+rec['u'])*256-.5;y=(.5-rec['v'])*256-.5;col=h['colors'][rec['sample']];ax[0].plot(x,y,'o',ms=3,mfc='white',mec=col);ax[0].annotate(rec['sample'],(x,y),xytext=(3,-6),textcoords='offset points',fontsize=6.5,color=col,bbox={'fc':'white','ec':'none','alpha':.8,'pad':.2})
for j,coord in enumerate([0,1],1):
 h['axes_setup'](ax[j],coord,'(b) $xz$ projection'if j==1 else'(c) $yz$ projection')
 for rec in data['samples']:h['trajectory'](ax[j],rec,coord)
h['legend'](fig);save(fig,'physical-heliconical-pi-atlas')
# Linear-radiance components; no independent normalization.
for name,ids in [('physical-reflections',['reciprocal-v4']),('physical-reflections-full',['reciprocal','reciprocal-v4'])]:
 fig,axes=plt.subplots(len(ids),3,figsize=(7.2,len(ids)*2.35),squeeze=False,layout='constrained')
 for row,id in enumerate(ids):
  for j,(key,title)in enumerate([('total','Total'),('direct','Direct'),('reflected','Reflected')]):
   a=np.fromfile(E/'data'/f'{id}-{key}.f64','<f8').reshape(256,256,3);picture(axes[row,j],a,'('+chr(97+row*3+j)+') '+title);axes[row,j].plot(191.5,127.5,'o',ms=4,mfc='none',mec='#f000df',mew=1)
  axes[row,0].set_ylabel('$g='+('0.25'if id=='reciprocal'else'0.4')+'$',fontsize=10)
 save(fig,name)
# Distinct indefinite effects: no transmitted entrance root; post-exit axis crossing.
fig,ax=plt.subplots(1,4,figsize=(7.2,2.05),layout='constrained')
picture(ax[0],raw('hyperbolic-v1'),'(a) Axis parallel to $z$');h['axes_setup'](ax[1],1,'(b) Entrance reflection');hyp=json.loads((A/'data/hyperbolic-v1.json').read_text())
for rec in hyp['samples'][:3]:h['trajectory'](ax[1],rec,1)
picture(ax[2],raw('eng-2013-v4'),'(c) $g_a=20$');h['axes_setup'](ax[3],1,'(d) Upper sample P1')
for id,col,label in [('eng-2013-v1','#0072b2','$g_a=0$'),('eng-2013-v4','#ad359c','$g_a=20$')]:
 rec=next(r for r in json.loads((A/'data'/f'{id}.json').read_text())['samples']if r['sample']=='P1');h['colors']['P1']=col;h['trajectory'](ax[3],rec,1);ax[3].plot([],[],'--',color=col,label=label)
ax[3].legend(frameon=False,fontsize=6.5,loc='lower right');ax[3].plot(-2.736646568,0,'x',ms=5,color='#ad359c');save(fig,'physical-interfaces')
(R/'review/new-figure-hashes.json').write_text(json.dumps(manifest,indent=2));print(list(manifest))

manifest['physical-radial']=hashlib.sha256((P/'figures/physical-radial.pdf').read_bytes()).hexdigest()
(R/'review/new-figure-hashes.json').write_text(json.dumps(manifest,indent=2))
