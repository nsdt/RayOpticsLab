const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{O,P}=require('./engine.cjs');
const root=path.resolve(__dirname,'..'),old=path.resolve(__dirname,'../../experiments_20260927_revision/data');
const expected=JSON.parse(fs.readFileSync(path.join(root,'data/reflection-decomposition.json'))),report=[];
for(const record of expected){
 const {id,n,config}=record,arrays={};
 for(const name of ['linear','any_reflection']){
  const b=fs.readFileSync(path.join(old,id+'-n'+n+'.'+name+'.f64'));
  if(crypto.createHash('sha256').update(b).digest('hex')!==record.sourceSHA256[name])throw Error('source hash '+id);
  arrays[name]=new Float64Array(b.buffer,b.byteOffset,b.byteLength/8);
 }
 const total=arrays.linear,reflected=arrays.any_reflection,direct=new Float64Array(total.length);
 let min=0,closure=0,fullSum=0,refSum=0,footprint=0;
 for(let y=0;y<n;y++)for(let x=0;x<n;x++){
  const ray=P.camera(x,y,n,config),inside=!!O.hit(ray.o,ray.d,config.shape);if(inside)footprint++;
  for(let j=0;j<3;j++){const i=(y*n+x)*3+j;direct[i]=total[i]-reflected[i];min=Math.min(min,direct[i]);closure=Math.max(closure,Math.abs(total[i]-direct[i]-reflected[i]));if(inside){fullSum+=total[i];refSum+=reflected[i];}}
 }
 const ratio=refSum/fullSum;if(Math.abs(ratio-record.reflectedFractionOfSummedLinearRGBInsideLensFootprint)>1e-12)throw Error('fraction mismatch');
 for(const [name,a]of Object.entries({total,direct,reflected}))fs.writeFileSync(path.join(root,'data',id+'-'+name+'.f64'),Buffer.from(a.buffer,a.byteOffset,a.byteLength));
 report.push({id,footprintPixels:footprint,minimumDirectChannel:min,maximumReconstructionError:closure,reflectedFraction:ratio});
}
fs.writeFileSync(path.join(root,'data/decomposition-recomputed.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
