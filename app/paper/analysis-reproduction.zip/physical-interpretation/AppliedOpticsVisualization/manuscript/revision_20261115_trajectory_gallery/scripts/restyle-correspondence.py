from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[4];P=ROOT/'AppliedOpticsVisualization/manuscript';R=P/'revision_20261115_trajectory_gallery'
sys.path.insert(0,str(ROOT/'tmp/ao20261112-python'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
D=ROOT/'AppliedOpticsVisualization/experiments_20260927_revision/data'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'legend.fontsize':8.5,'pdf.fonttype':42})
def save(fig,name):
 for ext in ['pdf','png']:fig.savefig(P/'figures'/f'{name}.{ext}',dpi=260,bbox_inches='tight',pad_inches=.04)
 plt.close(fig)
land=json.loads((D/'landmark-rays.json').read_text())
fig,axes=plt.subplots(2,3,figsize=(7.3,4.6),layout='constrained')
colors={'U':'#1260c4','D':'#df9400','L':'#00984a','R':'#9c359d'}
rr=np.linspace(-1,1,401);zz=1-rr*rr/(.6+np.sqrt(.36+.69*rr*rr))
for row,ident in enumerate(['reciprocal','radial-axis']):
 a=np.fromfile(D/f'{ident}-n256.linear.f64','<f8').reshape(256,256,3)
 a=np.clip(np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055),0,1)
 axes[row,0].imshow(a,interpolation='nearest');axes[row,0].set_xticks([]);axes[row,0].set_yticks([])
 axes[row,0].set_title(['(a) $g=0.25$','(d) $R_r=7$'][row])
 rays=[l for l in land['records'] if l['id']==ident]
 for j,coord in enumerate([0,1],1):
  ax=axes[row,j];ax.fill_betweenx(rr,-1,zz,color='#ecf0f4');ax.plot(zz,rr,color='#5d6a77',lw=.7)
  ax.plot([-1,-1],[-1,1],color='#5d6a77',lw=.7)
  ax.set(xlim=(-3.2,4.2),ylim=(-1.12,1.12),xlabel='$z/L$',ylabel='$x/L$' if coord==0 else '$y/L$',title='('+chr(97+row*3+j)+')')
  ax.grid(alpha=.15)
 for l in rays:
  col=colors[l['label']];marker='o' if l['mode']==0 else 'x';px,py=[(v+.5)*256/384-.5 for v in l['pixel']]
  axes[row,0].plot(px,py,marker=marker,color=col,ms=4.5,mfc='none',mew=1.1)
  seg=np.array(l['leaf']['segments'][0]['states']);entry=l['leaf']['events'][0]['position'];ex=l['leaf']['events'][1]['position']
  points=np.vstack([l['camera']['o'],entry,seg[:,:3],ex,l['target']])
  for j,coord in enumerate([0,1],1):axes[row,j].plot(points[:,2],points[:,coord],'-' if l['mode']==0 else '--',color=col,lw=1.05)
handles=[Line2D([],[],color=colors[k],label=k,lw=2) for k in colors]+[Line2D([],[],color='black',ls='-',label='Ordinary'),Line2D([],[],color='black',ls='--',label='Extraordinary')]
fig.legend(handles=handles,loc='outside lower center',ncol=6,frameon=False)
save(fig,'compact-landmark-rays')

fig,axes=plt.subplots(3,3,figsize=(7.3,6.8),layout='constrained')
colors={'U':'#1260c4','D':'#df9400','L':'#00984a','R':'#9c359d'}
rr=np.linspace(-1,1,401);zz=1-rr*rr/(.6+np.sqrt(.36+.69*rr*rr))
for row,ident in enumerate(['reciprocal','heliconical','radial-axis']):
 a=np.fromfile(D/f'{ident}-n256.linear.f64','<f8').reshape(256,256,3)
 a=np.clip(np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055),0,1)
 axes[row,0].imshow(a,interpolation='nearest');axes[row,0].set_xticks([]);axes[row,0].set_yticks([])
 axes[row,0].set_title(['(a) $g=0.25$','(d) $\\omega=2.5$','(g) $R_r=7$'][row])
 rays=[l for l in land['records'] if l['id']==ident]
 for j,coord in enumerate([0,1],1):
  ax=axes[row,j];ax.fill_betweenx(rr,-1,zz,color='#ecf0f4');ax.plot(zz,rr,color='#5d6a77',lw=.7)
  ax.plot([-1,-1],[-1,1],color='#5d6a77',lw=.7)
  ax.set(xlim=(-3.2,4.2),ylim=(-1.12,1.12),xlabel='$z/L$',ylabel='$x/L$' if coord==0 else '$y/L$',title='('+chr(97+row*3+j)+')')
  ax.grid(alpha=.15)
 for l in rays:
  col=colors[l['label']];marker='o' if l['mode']==0 else 'x';px,py=[(v+.5)*256/384-.5 for v in l['pixel']]
  axes[row,0].plot(px,py,marker=marker,color=col,ms=4.5,mfc='none',mew=1.1)
  seg=np.array(l['leaf']['segments'][0]['states']);entry=l['leaf']['events'][0]['position'];ex=l['leaf']['events'][1]['position']
  points=np.vstack([l['camera']['o'],entry,seg[:,:3],ex,l['target']])
  for j,coord in enumerate([0,1],1):axes[row,j].plot(points[:,2],points[:,coord],'-' if l['mode']==0 else '--',color=col,lw=1.05)
handles=[Line2D([],[],color=colors[k],label=k,lw=2) for k in colors]+[Line2D([],[],color='black',ls='-',label='Ordinary'),Line2D([],[],color='black',ls='--',label='Extraordinary')]
fig.legend(handles=handles,loc='outside lower center',ncol=6,frameon=False)
save(fig,'fig06-landmark-rays')
