from pathlib import Path
import sys,json,hashlib,shutil
ROOT=Path(__file__).resolve().parents[4];P=ROOT/'AppliedOpticsVisualization/manuscript';R=P/'revision_20261116_equations';A=ROOT/'AppliedOpticsVisualization/experiments_20261115_trajectory_gallery';E=ROOT/'AppliedOpticsVisualization/experiments_20261115_physical'
sys.path.insert(0,str(ROOT/'tmp/ao20261112-python'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
source=(A/'scripts/figures.py').read_text();h={'__file__':str(A/'scripts/figures.py')};exec(compile(source[:source.index('for group in [')],str(A/'scripts/figures.py'),'exec'),h)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':8.5,'axes.labelsize':8,'legend.fontsize':8.2,'pdf.fonttype':42})
manifest={}
def picture(ax,path,n,rows,label):
 a=np.fromfile(path,'<f8').reshape(n,n,3);a=np.clip(np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055),0,1);ax.imshow(a,interpolation='nearest');ax.set(xticks=[],yticks=[],title=label)
 for rec in rows[:5]:ax.plot((.5+rec['u'])*n-.5,(.5-rec['v'])*n-.5,'o',ms=3,mfc='none',mec=h['colors'][rec['sample']],mew=.8)
def setup(ax,coord,title,right=True,bottom=True):
 h['axes_setup'](ax,coord,title);ax.set(ylabel='',xlabel='$z/L$'if bottom else'');ax.tick_params(axis='y',left=False,labelleft=False,right=right,labelright=right,labelsize=8,pad=1);ax.tick_params(axis='x',bottom=bottom,labelbottom=bottom,labelsize=8,pad=1)
def legend(fig):
 hs=[Line2D([],[],color=c,lw=1.3,label=k)for k,c in h['colors'].items()]+[Line2D([],[],color='k',marker='s',mfc='white',ls='',label='Internal reflection')]
 fig.legend(handles=hs,loc='lower center',bbox_to_anchor=(.5,.002),ncol=6,frameon=False,handlelength=1.8,columnspacing=1.1,fontsize=8.2)
def save(fig,name,path,id):
 for ext in ['pdf','png']:
  output=P/'figures'/f'{name}.{ext}';backup=R/'baseline'/output.name
  if output.exists()and not backup.exists():shutil.copy2(output,backup)
  fig.savefig(output,dpi=300,bbox_inches='tight',pad_inches=.025)
 plt.close(fig);manifest[name]={'id':id,'input':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
for s in [s for s in h['cat']['cases']if s['kind']!='mono']:
 rows=h['data'](s)['samples'];path=h['source'](s)
 if s['kind']=='constant':
  fig,axs=plt.subplots(1,3,figsize=(7.2,2.5),gridspec_kw={'width_ratios':[1.2,2.55,2.55]});fig.subplots_adjust(left=.02,right=.965,top=.88,bottom=.23,wspace=.1)
  picture(axs[0],path,s['config']['resolution'],rows,'(a) $B=0$'if s['group'].startswith('iso-')else'(a) $B_o=B_e=0$')
  for j,coord in enumerate([0,1],1):
   setup(axs[j],coord,'$xz$ projection ($x/L$)'if j==1 else'$yz$ projection ($y/L$)',right=j==2)
   for rec in rows:h['trajectory'](axs[j],rec,coord)
 else:
  fig=plt.figure(figsize=(7.2,4.3));gs=fig.add_gridspec(2,4,width_ratios=[1.2,1.7,1.7,1.7],left=.02,right=.965,top=.92,bottom=.14,wspace=.1,hspace=.10)
  picture(fig.add_subplot(gs[:,0]),path,s['config']['resolution'],rows,'(a) Dispersive image')
  for j,nm in enumerate([450,550,650],1):
   for k,coord in enumerate([0,1]):
    ax=fig.add_subplot(gs[k,j]);setup(ax,coord,str(nm)+' nm'if k==0 else'',right=j==3,bottom=k==1)
    if j==3:ax.set_ylabel('$x/L$'if k==0 else'$y/L$',labelpad=3);ax.yaxis.set_label_position('right')
    for rec in rows:
     if rec['wavelength']==nm:h['trajectory'](ax,rec,coord)
 legend(fig);save(fig,'atlas-'+s['id'],path,s['id'])
rows=json.loads((E/'data/heliconical-pi-rays.json').read_text())['samples'];path=E/'data/heliconical-pi-n256.linear.f64';fig,axs=plt.subplots(1,3,figsize=(7.2,2.5),gridspec_kw={'width_ratios':[1.2,2.55,2.55]});fig.subplots_adjust(left=.02,right=.965,top=.88,bottom=.23,wspace=.1);picture(axs[0],path,256,rows,'(a) $\\omega=\\pi$')
for j,coord in enumerate([0,1],1):
 setup(axs[j],coord,'(b) $xz$ projection ($x/L$)'if j==1 else'(c) $yz$ projection ($y/L$)',right=j==2)
 for rec in rows:h['trajectory'](axs[j],rec,coord)
legend(fig);save(fig,'physical-heliconical-pi-atlas',path,'heliconical-pi')
(R/'review/remaining-atlas-inputs.json').write_text(json.dumps(manifest,indent=2));print('Restyled',len(manifest),'constant/spectral/pi atlases with unchanged camera images and trajectories.')
