from pathlib import Path
import sys,json,hashlib,shutil
ROOT=Path(__file__).resolve().parents[4];P=ROOT/'AppliedOpticsVisualization/manuscript';R=P/'revision_20261116_equations';A=ROOT/'AppliedOpticsVisualization/experiments_20261115_trajectory_gallery'
(R/'review').mkdir(parents=True,exist_ok=True)
(R/'baseline').mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'tmp/ao20261112-python'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
source=(A/'scripts/figures.py').read_text();h={'__file__':str(A/'scripts/figures.py')};exec(compile(source[:source.index('for group in [')],str(A/'scripts/figures.py'),'exec'),h)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':8,'axes.labelsize':8,'legend.fontsize':7.5,'pdf.fonttype':42})
cat=h['cat'];manifest={};groups=[g['id']for g in cat['groups']if not g['id'].endswith('-dispersion')]
for group in groups:
 specs=[c for c in cat['cases']if c['group']==group];fig=plt.figure(figsize=(7.2,4.9));grid=fig.add_gridspec(5,4,width_ratios=[.72,1.08,2.61,2.61],left=.01,right=.965,top=.94,bottom=.105,wspace=.10,hspace=.025);axes=[];records=[]
 for row,s in enumerate(specs):
  label=s['label'];label=label if '$'in label else'$'+label+'$';label=label.replace(', $','\n$')if group=='hyperbolic'else label
  lab=fig.add_subplot(grid[row,0]);lab.axis('off');lab.text(.0,.5,'('+chr(97+row)+')\n'+label,ha='left',va='center',fontsize=8.5)
  ax=fig.add_subplot(grid[row,1]);path=h['source'](s);n=s['config']['resolution'];a=np.fromfile(path,'<f8').reshape(n,n,3);display=np.clip(np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055),0,1);ax.imshow(display,interpolation='nearest');ax.set(xticks=[],yticks=[])
  for rec in h['data'](s)['samples'][:5]:
   ax.plot((.5+rec['u'])*n-.5,(.5-rec['v'])*n-.5,'o',ms=2.8,mfc='none',mec=h['colors'][rec['sample']],mew=.8)
  for j,coord in enumerate([0,1]):
   shared=axes[0][j]if axes else None;ax=fig.add_subplot(grid[row,j+2],sharex=shared,sharey=shared);h['axes_setup'](ax,coord,'')
   for rec in h['data'](s)['samples']:h['trajectory'](ax,rec,coord)
   ax.set(xlabel='$z/L$'if row==4 else'',ylabel='');ax.tick_params(axis='x',labelbottom=row==4,bottom=row==4,top=False);ax.tick_params(axis='y',labelsize=8,pad=1,left=False,labelleft=False,right=j==1,labelright=j==1);ax.tick_params(axis='x',labelsize=8,pad=1)
   for spine in ax.spines.values():spine.set_linewidth(.45);spine.set_color('#75818a')
   if row==0:ax.set_title('$xz$ projection ($x/L$)'if j==0 else'$yz$ projection ($y/L$)',pad=3)
   if j==0:rowaxes=[]
   rowaxes.append(ax)
  axes.append(rowaxes);records.append({'id':s['id'],'input':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 handles=[Line2D([],[],color=c,lw=1.3,label=k)for k,c in h['colors'].items()]+[Line2D([],[],color='k',marker='s',mfc='white',ls='',label='Internal reflection')]
 fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,-.002),ncol=6,frameon=False,handlelength=1.8,columnspacing=1.1,fontsize=8.2)
 for ext in ['pdf','png']:
  output=P/'figures'/f'atlas-{group}.{ext}';backup=R/'baseline'/output.name
  if output.exists() and not backup.exists():shutil.copy2(output,backup)
  fig.savefig(output,dpi=300,bbox_inches='tight',pad_inches=.025)
 plt.close(fig);manifest[group]=records
(R/'review/compact-atlas-inputs.json').write_text(json.dumps(manifest,indent=2));print('Compacted',len(manifest),'atlases; all original 75 camera images and path records retained.')
