# Physical interpretation and camera trajectory records (15 November 2026)

The article contains 11 pages and Supplement 1 contains 29 pages. All 15 media
remain in the article. The original 79 image conditions are retained; the exact
heliconical condition omega = pi adds one CPU reference image (256 x 256).

This archive is self-contained for the new physical comparisons and the earlier
79-condition camera trajectory atlas. Run commands from the extracted root with
Node.js and Python (NumPy and Matplotlib):

    node AppliedOpticsVisualization/experiments_20261115_physical/scripts/render-pi.cjs
    node AppliedOpticsVisualization/experiments_20261115_physical/scripts/analyze.cjs
    node AppliedOpticsVisualization/experiments_20261115_physical/scripts/decompose.cjs
    python AppliedOpticsVisualization/experiments_20261115_physical/scripts/figures.py

The first command recalculates the pi camera image. Existing arrays and path
records are included, so it may be omitted when only regenerating figures.
The second command calculates five representative camera directions and checks
archived reciprocal total/reflected channels at 37 lens-intersecting pixels per
condition. These are consistency checks with the same engine, not an independent
implementation. The third command extracts direct = total - reflected in linear
RGB and checks source hashes and the reported scene-dependent fractions. The
fourth command generates article Figures 3, 4, 7, 8 and supplemental Figures S23,
S24. Figure numbers in earlier dated analyses retain their original meaning.

The reciprocal gradients are 0.25 and 0.4. Reflected contributions include every
path with at least one reflection, including entrance reflection. No separate
brightness normalization is applied. The ratio of summed reflected RGB to total
RGB over lens-intersecting pixels is 16.6% or 34.6%; this is not a material
reflectance. Roundoff may produce direct channels down to -3.4e-16.

At omega = pi, the central extraordinary path has nonzero internal transverse
excursions but zero net transverse displacement at the planar exit, within the
recorded numerical residual. Off-axis image deformation remains. This condition
is not included in the earlier 120-landmark analysis or 79-condition GPU test.

Ordinary paths are solid; extraordinary paths are dashed. Fixed-camera samples
share incident directions. Separately solved camera-to-landmark connections
reach the same object landmark with generally different camera directions.

The exact CPU engine, pixel sampling protocol, original image arrays, source
hashes, five-direction path records, and all plotting dependencies are included.
The application continues to prefer GPU with CPU fallback for user calculations;
no CPU/GPU engine code was modified in this revision. Historical GPU timing and
accuracy measurements are not reinterpreted as measurements of the new pi case.

See ORIGINAL_TRAJECTORY_ATLAS_README.md for the earlier atlas commands. Its
article figure numbering predates this physical interpretation revision.
