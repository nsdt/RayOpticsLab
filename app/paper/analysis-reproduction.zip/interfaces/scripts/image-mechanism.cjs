const {O,F,base,camera,T,read,root,save}=require('./common.cjs');
const path=require('node:path'),assert=require('node:assert/strict');
const input=read(path.join(root,'configs/landmark-input.json'));
function geometry(pixel,c,mode){
 const ray=camera(...pixel,384,c),entry=O.hit(ray.o,ray.d,c.shape);assert(entry);
 const p=O.boundary(entry,ray.d,O.normal(entry,c.shape),c,mode,true);assert(p);
 const E=F.fields(F.cv(p),F.localMaterial(c,entry),mode).E;
 const initial=F.launch(entry,{p,E,mode},c,{}),end=F.propagate(initial,{...c,paperCapture:true});
 const d=O.exitDirection(end.p,O.normal(end.o,c.shape),c);assert(d);
 const t=O.backgroundDistance(end.o,d,c);assert(Number.isFinite(t));
 const vin=O.unit(O.velocity(entry,p,c,mode)),vout=O.unit(O.velocity(end.o,end.p,c,mode));
 const slope=v=>v.slice(0,2).map(x=>x/v[2]);
 assert(Math.abs(vin[2])>.05&&Math.abs(vout[2])>.05&&Math.abs(d[2])>.05);
 const eta=x=>c.material==='common'?1/(1+c.gradient*x[2])**2:1+c.gradient*x[2]**2;
 return {pixel,entry,entryP:p,entryDirection:vin,exit:end.o,exitP:end.p,interiorExitDirection:vout,exteriorDirection:d,background:O.add(end.o,O.mul(d,t)),
  entranceSlope:slope(vin),interiorSlope:slope(vout),exteriorSlope:slope(d),entryEta:eta(entry),exitEta:eta(end.o),
  hResidual:Math.max(Math.abs(2*O.H(entry,p,c,mode)-1),Math.abs(2*O.H(end.o,end.p,c,mode)-1)),path:end.paperSegment};
}
const sub=(a,b)=>a.map((v,i)=>v-b[i]),add=(a,b)=>a.map((v,i)=>v+b[i]),mul=(a,v)=>a.map(x=>x*v),norm=a=>Math.hypot(...a);
const records=[];
for(const group of ['reciprocal','quadratic']){
 const baseline=input.records.find(r=>r.group===group&&r.value===0);
 const reference=baseline.points.map(p=>({label:p.label,mode:p.mode,state:geometry(p.pixel,baseline.c,p.mode)}));
 for(const spec of input.records.filter(r=>r.group===group)){
  const rays=[];
  for(const ref of reference){
   const a=ref.state,b=geometry(a.pixel,spec.c,ref.mode),matched=input.records.find(r=>r.group===group&&r.value===spec.value).points.find(p=>p.mode===ref.mode&&p.label===ref.label);
   const connection=geometry(matched.pixel,spec.c,ref.mode),target=T.landmarks.find(p=>p.label===ref.label);
   assert(Math.hypot(connection.background[0]-target.x,connection.background[1]-target.y)<1e-9);
   const dx=sub(b.exit,a.exit),ds=sub(b.exteriorSlope,a.exteriorSlope),meanSlope=mul(add(a.exteriorSlope,b.exteriorSlope),.5),meanLength=spec.c.backgroundZ-(a.exit[2]+b.exit[2])*.5;
   const positionTerm=sub(dx.slice(0,2),mul(meanSlope,dx[2])),directionTerm=mul(ds,meanLength),backgroundChange=sub(b.background.slice(0,2),a.background.slice(0,2));
   const entranceTerm=sub(b.entranceSlope,a.entranceSlope),bulkTerm=sub(sub(b.interiorSlope,b.entranceSlope),sub(a.interiorSlope,a.entranceSlope)),exitTerm=sub(sub(b.exteriorSlope,b.interiorSlope),sub(a.exteriorSlope,a.interiorSlope));
   const identityResidual=norm(sub(add(positionTerm,directionTerm),backgroundChange)),slopeResidual=norm(sub(add(add(entranceTerm,bulkTerm),exitTerm),ds));
   const refined=geometry(a.pixel,{...spec.c,step:spec.c.step/2},ref.mode);
   const refinementDifference=norm(sub(refined.background,b.background));
   const kappa=b.entryP.slice(0,2),predicted=[...kappa,-Math.sqrt(1-kappa.reduce((s,v)=>s+v*v,0))];
   const transverseConservation=norm(sub(kappa,b.exitP.slice(0,2))),directionPrediction=norm(sub(predicted,b.exteriorDirection));
   assert(Math.abs(b.exit[2]+1)<1e-9&&transverseConservation<1e-9&&directionPrediction<1e-9);
   const ray=camera(...a.pixel,384,spec.c),full=F.trace(ray.o,ray.d,{...spec.c,paperCapture:true});assert.equal(full.status,'ok');
   const leaves=(full.paperLeaves||[]).filter(l=>!l.reflected&&l.segments[0]?.mode===ref.mode&&l.q&&norm(sub(l.q,b.background))<1e-8);assert(leaves.length>0);
   const completePathDifference=Math.max(...leaves.map(l=>norm(sub(l.q,b.background))));
   assert(identityResidual<1e-12&&slopeResidual<1e-12&&refinementDifference<1e-8);
   rays.push({label:ref.label,mode:ref.mode,reference:a,state:b,connection,pixelChange:sub(matched.pixel,a.pixel),backgroundChange,positionTerm,directionTerm,entranceTerm,bulkTerm,exitTerm,identityResidual,slopeResidual,refinementDifference,transverseConservation,directionPrediction,completePathDifference});
  }
  records.push({group,value:spec.value,config:spec.c,rays});save('image-mechanism',{records});
  console.log(group,spec.value,'rays',rays.length,'max refinement',Math.max(...rays.map(r=>r.refinementDifference)));
 }
}