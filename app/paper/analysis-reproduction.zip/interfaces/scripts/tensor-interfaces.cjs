const {O,F,base,read,root,save}=require('./common.cjs');
const path=require('node:path'),assert=require('node:assert/strict');
const input=read(path.join(root,'data/tensor-interface-input.json')),air={...base,material:'isotropic',n:1};
const norm=a=>Math.hypot(...a),dist=(a,b)=>norm(a.map((x,i)=>x-b[i]));
const kdist=(a,b)=>norm(a.flatMap((z,i)=>[z[0]-b[i][0],z[1]-b[i][1]]));
const records=[];let failures=[];
for(let index=0;index<input.records.length;index++){
 const c=input.records[index],medium=F.localMaterial({...base,...c.config},c.position),reverse=c.incidence==='interior';
 const globalConfig={...base,...c.config};
 const from=reverse?medium:air,to=reverse?air:medium,N=c.normal,t=O.add(c.incident.p,O.mul(N,-O.dot(c.incident.p,N)));
 try {
  const result=F.scatter(c.incident,from,to,N);let root=0,direction=0,propagatingModes=0,evanescentModes=0;
  for(const [medium,sign,expected] of [[from,-1,c.expected.reflectedModes],[to,1,c.expected.transmittedModes]]){
   const actual=F.modes(medium,t,N,sign);
   const permutations=[[0,1],[1,0]];permutations.sort((a,b)=>a.reduce((s,j,i)=>s+kdist(actual[i].k,expected[j].k),0)-b.reduce((s,j,i)=>s+kdist(actual[i].k,expected[j].k),0));
   for(let i=0;i<2;i++){
    const a=actual[i],e=expected[permutations[0][i]];assert.equal(a.prop,e.prop);
    root=Math.max(root,kdist(a.k,e.k));
    if(a.prop){propagatingModes++;direction=Math.max(direction,dist(F.rayDirection({p:a.p,E:a.E,o:c.position,mode:a.mode},medium===air?air:globalConfig),e.direction));}
    else evanescentModes++;
   }
  }
  let power=0;
  for(const reflection of [false,true]){
   const sum=list=>list.filter(b=>b.reflection===reflection).reduce((s,b)=>s+b.weight,0);
   power=Math.max(power,Math.abs(sum(result.children)-sum(c.expected.branches)));
  }
  for(const e of c.expected.branches){
   const a=result.children.find(a=>a.reflection===e.reflection&&dist(a.p,e.p)<1e-7);
   power=Math.max(power,Math.abs((a?.weight||0)-e.weight));
   if(e.weight>1e-12){assert(a);direction=Math.max(direction,dist(F.rayDirection({...a,o:c.position},(a.reflection?from:to)===air?air:globalConfig),e.direction));}
  }
  for(const a of result.children)assert(c.expected.branches.some(e=>e.reflection===a.reflection&&dist(a.p,e.p)<1e-7)||a.weight<1e-12);
  records.push({index,medium:c.medium,incidence:c.incidence,angle:c.angle,polarization:c.polarization,position:c.position,normal:c.normal,
   errors:{power,root,direction,conservation:result.error,boundary:result.residual},reference:c.reference,
   propagatingModes,evanescentModes,totalReflection:c.incidence==='exterior'&&!c.expected.branches.some(b=>!b.reflection&&b.weight>1e-12),
   negativeNormalPhase:c.expected.transmittedModes.some(m=>m.prop&&O.dot(m.k.map(z=>z[0]),N)<-1e-10)});
 }catch(error){failures.push({index,medium:c.medium,position:c.position,angle:c.angle,normal:c.normal,polarization:c.polarization,incidence:c.incidence,message:error.message});}
}
const summary=[];
for(const medium of [...new Set(records.map(r=>r.medium))]){
 const r=records.filter(r=>r.medium===medium);
 summary.push({medium,count:r.length,reverse:r.filter(r=>r.incidence==='interior').length,totalReflection:r.filter(r=>r.totalReflection).length,
  evanescentConditions:r.filter(r=>r.evanescentModes>0).length,negativeNormalPhase:r.filter(r=>r.negativeNormalPhase).length,
  max:Object.fromEntries(Object.keys(r[0].errors).map(k=>[k,Math.max(...r.map(x=>x.errors[k]))])),referenceMax:Object.fromEntries(Object.keys(r[0].reference).map(k=>[k,Math.max(...r.map(x=>x.reference[k]))]))});
}
save('tensor-interfaces',{count:records.length,failures,summary,records});console.log(JSON.stringify({count:records.length,failures:failures.slice(0,10),failureCount:failures.length,summary},null,2));
assert.equal(failures.length,0);assert(records.every(r=>Math.max(...Object.values(r.errors))<1e-9));