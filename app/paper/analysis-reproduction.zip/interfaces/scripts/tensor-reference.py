"""Independent Maxwell interface calculation for signed and magnetic tensors.
Only prescribed constitutive tensors and Maxwell equations enter the reference.
"""
from pathlib import Path
import json,math
import bootstrap
import numpy as np
R=Path(__file__).resolve().parents[1]
manifest=json.loads((R/'configs/manifest.json').read_text(encoding='utf-8-sig'))
configs={r['id']:r['config'] for r in manifest if r['role']=='representative'}
vec=lambda v:[[float(z.real),float(z.imag)] for z in np.asarray(v,dtype=complex)]
unit=lambda x:x/np.linalg.norm(x)
def tensors(name,c,x):
 if name=='hyperbolic':
  th,ph=np.deg2rad([c['tilt'],c['azimuth']]);a=np.array([np.sin(th)*np.cos(ph),np.sin(th)*np.sin(ph),np.cos(th)])
  eta=1+c['gradient']*x[2];eo=-c['no']**2*eta;ee=c['ne']**2*eta
  return eo*np.eye(3)+(ee-eo)*np.outer(a,a),np.eye(3)
 if name=='eng-2013':
  a=1+c['engStrength']*x[2]**2
  return np.diag([-.5*a,.5*a,-2*a]),np.diag([.5,.5,2.])
 if name=='shear':
  t=(x[2]+1)/2;b=-3*c['shift']*t*(1-t);J=np.array([[1,0,b],[0,1,.45*b],[0,0,1.]])
 else:
  d=x-np.array(c.get('transformCenter',[.7,0,-3.]));axes=[0,1,2] if name=='spherical-map' else [0,2]
  radius=np.linalg.norm(d[axes]);ri=c['transformInner'];ro=c['transformOuter'];scale=ro/(ro-ri);alpha=scale*(1-ri/radius)
  J=np.eye(3)
  for i in axes:
   for j in axes:J[i,j]=alpha*(i==j)+scale*ri*d[i]*d[j]/radius**3
 C=np.linalg.det(J)*np.linalg.inv(J)@np.linalg.inv(J).T
 return C,C.copy()
def state_fields(f,eps,mu,t):
 Ex,Ey,Hx,Hy=f;kx,ky=t
 Ez=-(eps[2,0]*Ex+eps[2,1]*Ey+kx*Hy-ky*Hx)/eps[2,2]
 Hz=(kx*Ey-ky*Ex-mu[2,0]*Hx-mu[2,1]*Hy)/mu[2,2]
 return np.array([Ex,Ey,Ez]),np.array([Hx,Hy,Hz])
def flux(f):return float(.5*np.real(f[0]*np.conj(f[3])-f[1]*np.conj(f[2])))
def modes(eps,mu,t):
 cols=[]
 for f in np.eye(4):
  E,H=state_fields(f,eps,mu,t);D=eps@E;B=mu@H;kx,ky=t
  cols.append([kx*E[2]+B[1],ky*E[2]-B[0],kx*H[2]-D[1],ky*H[2]+D[0]])
 M=np.column_stack(cols);values,V=np.linalg.eig(M);out=[]
 for q,f in zip(values,V.T):
  if abs(q.imag)<1e-10:q=complex(q.real,0)
  E,H=state_fields(f,eps,mu,t);k=np.array([*t,q]);S=.5*np.real(np.cross(E,np.conj(H)))
  residual=max(np.linalg.norm(np.cross(k,E)-mu@H),np.linalg.norm(np.cross(k,H)+eps@E))/max(np.linalg.norm(E),np.linalg.norm(H))
  out.append(dict(q=q,f=f,E=E,H=H,S=S,prop=bool(q.imag==0),residual=float(residual)))
 assert max(o['residual'] for o in out)<1e-10
 return out

def outgoing(ms,side):
 a=[m for m in ms if (side*flux(m['f'])>1e-10 if m['prop'] else side*m['q'].imag>1e-10)]
 assert len(a)==2,[(m['q'],flux(m['f'])) for m in ms]
 return a

def serialize_modes(ms,Q,t):
 return [dict(k=vec(Q@np.array([*t,m['q']])),prop=m['prop'],direction=(Q@unit(m['S'])).tolist() if m['prop'] else None) for m in ms]

def solve_case(name,c,x,Q,t,ma,mm,side,incident,label,angle,azimuth):
 source,target=(ma,mm) if side==1 else (mm,ma)
 reflected=outgoing(source,-side);transmitted=outgoing(target,side)
 F0=side*flux(incident['f']);assert F0>1e-10
 A=np.column_stack([m['f'] for m in transmitted]+[-m['f'] for m in reflected])
 amplitudes=np.linalg.solve(A,incident['f']);branches=[]
 for ms,amps,is_ref in [(transmitted,amplitudes[:2],False),(reflected,amplitudes[2:],True)]:
  groups=[]
  for m,a in zip(ms,amps):
   if not m['prop']:continue
   group=next((g for g in groups if abs(g['q']-m['q'])<1e-8),None)
   if group is None:group=dict(q=m['q'],E=np.zeros(3,complex),H=np.zeros(3,complex));groups.append(group)
   group['E']+=a*m['E'];group['H']+=a*m['H']
  for g in groups:
   S=.5*np.real(np.cross(g['E'],np.conj(g['H'])));w=abs(float(S[2]))/F0
   if w<1e-24:continue
   branches.append(dict(reflection=is_ref,p=(Q@np.array([*t,g['q'].real])).tolist(),direction=(Q@unit(S)).tolist(),weight=w))
 total=sum(b['weight'] for b in branches);balance=abs(total-1)
 assert balance<1e-10,(name,angle,label,balance)
 resid=float(np.linalg.norm(A@amplitudes-incident['f'])/np.linalg.norm(incident['f']))
 return dict(medium=name,config=c,position=x.tolist(),normal=(side*Q[:,2]).tolist(),normalPolarAngle=0 if abs(Q[2,2]-1)<1e-10 else 30,angle=angle,azimuth=azimuth,incidence='exterior' if side==1 else 'interior',polarization=label,
  incident=dict(p=(Q@np.array([*t,incident['q'].real])).tolist(),E=vec(Q@incident['E'])),
  expected=dict(branches=branches,reflectedModes=serialize_modes(reflected,Q,t),transmittedModes=serialize_modes(transmitted,Q,t)),
  reference=dict(conservation=balance,boundaryResidual=resid,maxwellResidual=max(m['residual'] for m in ma+mm),condition=float(np.linalg.cond(A))))

records=[]
for name in ['hyperbolic','eng-2013','shear','spherical-map','cylindrical-map']:
 c=configs[name]
 for x in np.array([[0,0,-.5],[.4,.2,0],[-.3,.2,.5]]):
  eps,mu=tensors(name,c,x)
  for theta in [0,30]:
   th=np.deg2rad(theta);ph=np.pi/4;n=np.array([np.sin(th)*np.cos(ph),np.sin(th)*np.sin(ph),np.cos(th)])
   u=np.array([np.cos(th)*np.cos(ph),np.cos(th)*np.sin(ph),-np.sin(th)]);Q=np.column_stack([u,np.cross(n,u),n])
   e=Q.T@eps@Q;m=Q.T@mu@Q
   for angle in [0,30,60]:
    for azimuth in [0,45]:
     inc=np.deg2rad(angle);az=np.deg2rad(azimuth);t=np.sin(inc)*np.array([np.cos(az),np.sin(az)]);q=np.cos(inc)
     ma=modes(np.eye(3),np.eye(3),t);mm=modes(e,m,t)
     s=np.array([-np.sin(az),np.cos(az),0]);p=np.array([q*np.cos(az),q*np.sin(az),-np.sin(inc)])
     for label,cs,cp in [('s',1,0),('p',0,1),('diagonal',2**-.5,2**-.5),('circular',2**-.5,1j*2**-.5)]:
      E=cs*s+cp*p;H=np.cross([*t,q],E);f=np.array([E[0],E[1],H[0],H[1]])
      records.append(solve_case(name,c,x,Q,t,ma,mm,1,dict(q=q,E=E,f=f),label,angle,azimuth))
     for j,mode in enumerate(outgoing(mm,-1)):
      if mode['prop']:records.append(solve_case(name,c,x,Q,t,ma,mm,-1,mode,'mode-'+str(j),angle,azimuth))
result={'description':'Independent Maxwell eigenproblem with general real symmetric epsilon and mu; local tensors prescribed separately from renderer metrics. Repeated transformation roots are combined as coherent fields.','records':records}
(R/'data/tensor-interface-input.json').write_text(json.dumps(result,indent=2),encoding='utf8')
for name in configs:
 rows=[r for r in records if r['medium']==name]
 if rows:print(name,len(rows),'reverse',sum(r['incidence']=='interior' for r in rows),'max reference flux residual',max(r['reference']['conservation'] for r in rows))