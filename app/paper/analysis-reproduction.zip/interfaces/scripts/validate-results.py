from pathlib import Path
import json,math
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'data'/f'{n}.json').read_text(encoding='utf8'))
a=read('tensor-interfaces'); oracle=read('tensor-interface-input'); d=read('image-mechanism'); summary=read('summary')
assert a['count']==len(a['records'])==len(oracle['records'])==992 and not a['failures']
assert sum(r['incidence']=='exterior' for r in a['records'])==720
assert sum(r['incidence']=='interior' for r in a['records'])==272
counts={'hyperbolic':168,'eng-2013':180,'shear':216,'spherical-map':212,'cylindrical-map':216}
for row in a['summary']:
 records=[r for r in a['records'] if r['medium']==row['medium']]
 assert row['count']==len(records)==counts[row['medium']]
 for key,value in row['max'].items():
  assert value==max(r['errors'][key] for r in records) and math.isfinite(value) and value<1e-9
 for key,value in row['referenceMax'].items():
  assert value==max(r['reference'][key] for r in records) and math.isfinite(value)
  assert value<(100 if key=='condition' else 1e-9)
assert set(r['medium'] for r in a['summary'])==set(counts)
assert sum(r['negativeNormalPhase'] for r in a['records'] if r['medium']=='hyperbolic')>0
assert all(any(r['evanescentModes']>0 for r in a['records'] if r['medium']==m) for m in ['hyperbolic','eng-2013'])
assert len(d['records'])==10
rays=[p for r in d['records'] for p in r['rays']]; assert len(rays)==80
for group in ['reciprocal','quadratic']:
 records=[r for r in d['records'] if r['group']==group]
 assert sorted(r['value'] for r in records)==[0,.1,.2,.3,.4]
 for row in records:
  assert set((p['label'],p['mode']) for p in row['rays'])=={(label,mode) for label in ['U','D','L','R'] for mode in [0,1]}
  for p in row['rays']:
   assert p['reference']['pixel']==p['state']['pixel']
   assert p['reference']['entry']==p['state']['entry']
   assert abs(p['state']['exit'][2]+1)<1e-9
   assert max(abs(sum(v)-total) for v,total in zip(zip(p['positionTerm'],p['directionTerm']),p['backgroundChange']))<1e-12
   assert p['refinementDifference']<1e-8 and p['completePathDifference']<1e-8
   assert p['identityResidual']<1e-12 and p['slopeResidual']<1e-12
   assert p['directionPrediction']<1e-12 and p['transverseConservation']<1e-12
   if row['value']==.4:
    radius=lambda xy:math.hypot(xy[0]-191.5,xy[1]-191.5)
    delta=radius(p['connection']['pixel'])-radius(p['reference']['pixel'])
    assert delta<0 if group=='reciprocal' else delta>0
for key,value in summary['image']['maximum'].items():assert value==max(p[key] for p in rays)
assert summary['interface']==a['summary']
report={'status':'passed','interfaceConditions':992,'exteriorConditions':720,'interiorConditions':272,'models':counts,'maxPowerDifference':max(r['errors']['power'] for r in a['records']),'maxComplexCovectorDifference':max(r['errors']['root'] for r in a['records']),'maxEnergyDirectionDifference':max(r['errors']['direction'] for r in a['records']),'fixedCameraTrajectories':80,'imageChecks':summary['image']['maximum'],'allEightLandmarkPositionsContractOrExpandAtG04':True}
(R/'data/validation.json').write_text(json.dumps(report,indent=2),encoding='utf8'); print(json.dumps(report,indent=2))