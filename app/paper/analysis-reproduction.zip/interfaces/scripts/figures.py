from pathlib import Path
import json,math,shutil
import bootstrap
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];D=R/'data';F=R/'figures';P=R.parent/'manuscript'
d=json.loads((D/'image-mechanism.json').read_text());it=json.loads((D/'tensor-interfaces.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':9,'axes.titlesize':10,'legend.fontsize':8,'pdf.fonttype':42})
fig,axes=plt.subplots(2,2,figsize=(7.3,5.1),gridspec_kw={'hspace':.44,'wspace':.24})
colors=['#222222','#0072b2','#d55e00'];ls=['-', '--', '-.']
for col,group in enumerate(['reciprocal','quadratic']):
 rows=[r for r in d['records'] if r['group']==group];top=axes[0,col];bottom=axes[1,col]
 for g,color,style in zip([0,.2,.4],colors,ls):
  r=next(r for r in rows if r['value']==g);p=next(p for p in r['rays'] if p['label']=='R' and p['mode']==1);a=p['state']
  path=np.array([a['entry'],*[v[:3] for v in a['path']],a['exit']])
  top.plot(path[:,2],path[:,0],ls=style,color=color,lw=1.5,label=f'$g={g:g}$')
  top.plot([a['entry'][2]],[a['entry'][0]],'o',color=color,ms=4)
  top.plot([a['exit'][2]],[a['exit'][0]],'s',color=color,ms=4)
 top.set_title(['(a)','(b)'][col],loc='left');top.set_xlabel('$z$');top.set_ylabel('$x$');top.set_xlim(-1.08,1.02);top.set_ylim(.1,.85);top.grid(alpha=.2)
 top.legend(loc='lower left',ncol=3,frameon=False,handlelength=1.3,columnspacing=1.1)
 p=[next(p for p in r['rays'] if p['label']=='R' and p['mode']==1) for r in rows];g=[r['value'] for r in rows]
 for key,label,color,marker in [('positionTerm','Exit position','#0072b2','o'),('directionTerm','Exit direction','#d55e00','s'),('backgroundChange','Total','#222222','^')]:
  bottom.plot(g,[v[key][0] for v in p],label=label,color=color,marker=marker,ms=4,lw=1.2)
 bottom.axhline(0,color='#aaaaaa',lw=.6);bottom.set_title(['(c)','(d)'][col],loc='left');bottom.set_xlabel('$g$');bottom.set_ylabel(r'$\Delta q_x$');bottom.set_xticks([0,.1,.2,.3,.4]);bottom.set_ylim(-.42,.75);bottom.grid(alpha=.2)
handles,labels=axes[1,0].get_legend_handles_labels();fig.legend(handles,labels,ncol=3,loc='lower center',bbox_to_anchor=(.5,.005),frameon=False)
fig.subplots_adjust(bottom=.14,top=.96)
for ext in ['pdf','png']:
 p=F/('image-mechanism.'+ext);fig.savefig(p,dpi=200)
 if (P/'figures').is_dir():shutil.copy2(p,P/'figures'/p.name)
plt.close(fig)
rays=[p for r in d['records'] for p in r['rays']]
summary={'interface':it['summary'],'interfaceCount':it['count'],'exteriorConditions':sum(r['incidence']=='exterior' for r in it['records']),'interiorConditions':sum(r['incidence']=='interior' for r in it['records']),
 'image':{'fixedRays':len(rays),'maximum':{k:max(p[k] for p in rays) for k in ['identityResidual','slopeResidual','refinementDifference','transverseConservation','directionPrediction','completePathDifference']},'representative':[]}}
for group in ['reciprocal','quadratic']:
 r=next(r for r in d['records'] if r['group']==group and r['value']==.4)
 for mode in [0,1]:
  p=next(p for p in r['rays'] if p['label']=='R' and p['mode']==mode)
  summary['image']['representative'].append({'group':group,'mode':mode,**{k:p[k] for k in ['pixelChange','backgroundChange','positionTerm','directionTerm','entranceTerm','bulkTerm','exitTerm']},'entryEta':p['state']['entryEta'],'exitEta':p['state']['exitEta'],'entryZ':p['state']['entry'][2]})
(D/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in summary.items() if k!='interface'},indent=2))
