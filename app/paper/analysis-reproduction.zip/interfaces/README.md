# Tensor-interface validation and physical interpretation of image deformation

12 November 2026. This archive contains the additional calculations for Sections 2.7, 2.8, 3.9 and 3.10 of the Applied Optics manuscript, including Figure 19 and the final five rows of Table 3. Earlier figures and results remain in the preceding contribution archive. No original image gallery was recomputed or altered.

## Reproduction

Python with requirements.txt and Node.js are required. The retained calculations used Node.js 24.22.1 and CPU double precision. No npm dependencies or GPU are required. From this directory:

```sh
python -m pip install -r requirements.txt
python scripts/tensor-reference.py
node scripts/tensor-interfaces.cjs
node scripts/image-mechanism.cjs
python scripts/figures.py
python scripts/validate-results.py
```

Each command replaces its named data or figure outputs. Preserve a separate copy of the supplied measurements if needed. To check the retained results without recomputation, run only validate-results.py. Plot regeneration requires only figures.py. The figure is also copied into a sibling manuscript/figures directory if present.

## Independent interface calculation

The Python reference constructs electric and magnetic tensors directly from constitutive parameters. It does not import optical metrics, polarization formulas or interface solvers from the renderer. Normal field components are eliminated from the two curl equations to form a 4 by 4 tangential Maxwell eigenproblem. Propagating outgoing modes are selected by normal Poynting flux; evanescent modes are selected by decay away from the interface. Four tangential continuity equations determine reflected and transmitted fields. Coincident transformation modes are combined coherently before comparison of power, avoiding dependence on the eigenvector basis of a degenerate subspace.

The 992 prescribed conditions comprise 720 exterior and 272 interior incidences. Three tensor evaluation positions, two interface-normal orientations, three exterior incidence angles, two tangential azimuths and four incident polarizations are evaluated for five material models. Reverse incidence includes every admissible propagating eigenstate. The maximum differences are 1.21e-14 in incident-power-normalized power coefficients, 4.48e-15 in the complex wave covector and 1.64e-15 in the unit energy direction. Raw roots, fields, reference residuals and individual comparisons are retained in data/.

The tests concern local interfaces for the prescribed ideal lossless tensors. They do not establish an error bound for complete images, absorption, broadband constitutive models, singular tensors or all multiple-reflection paths. In tensor-interfaces.json, totalReflection is a zero-transmitted-power flag for the prescribed polarization; it can include polarization extinction and must not be interpreted as an independent count of critical-angle total internal reflection.

## Image interpretation

Eighty direct trajectories are traced using fixed camera directions: two spatial profiles, five parameter values, four background marks and two modes. The baseline camera directions are the connections at g=0. The existing independently located landmark connections are supplied in configs/landmark-input.json; the connections are verified again against the background positions. This archive does not repeat their root search.

In the camera direction of tracing, the rays enter the aspherical rear surface and exit the front plane z=-1. The conserved transverse covector and tangential matching at the plane determine the exterior direction from the entrance covector. The background displacement is decomposed exactly into exit-position and exterior-direction contributions. Refinement of the propagation interval and confirmation in the complete path calculation are recorded. Both entrance refraction and internal propagation change with the parameter; this is not a counterfactual separation with fixed interface tensors. The observations apply to the selected connections and do not establish uniqueness of image points or a global magnification theorem.

## Provenance and contents

- engine/: 39 unchanged files from the preceding contribution experiment, originally archived for the manuscript images.
- scripts/engine.cjs: unchanged diagnostic wrapper from the same archive.
- configs/manifest.json: unchanged 75-scene manifest.
- configs/landmark-input.json: retained landmark-sweep results from the preceding contribution experiment.
- data/: independent reference states, comparison records, ray states, summary and validation report.
- figures/: the new Figure 19 as PDF and PNG.
- provenance.json and SHA256SUMS.json: source records and distributed-file hashes.

The numerical archive includes only calculation and validation scripts. Baseline manuscripts, historical authoring scripts, prose reviews, diffs and rendered PDF checks remain in the workspace review record. The canonical manuscript is still a single main.tex. Abstract, Discussion and Conclusion have not been added.