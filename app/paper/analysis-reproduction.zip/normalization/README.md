# Image-size normalization and manuscript reproduction

The 120 retained landmark connections are copied without modification into configs/landmark-input.json. The ordinary centroid, its RMS radius, the translation residual and the ratio of residual to radius are computed separately at each of the 15 parameter settings. The calculation checks the retained residuals, an independent pairwise-variance identity, invariance under common scale/rotation and separate translations, and rejection of zero radius.

Run from this directory:

```sh
python -m pip install -r requirements.txt
python scripts/normalized-landmarks.py
python scripts/figures.py
```

The first command after installation regenerates data/normalized-landmarks.json and .csv. The second generates Figure 18 as PDF and PNG. The upper panels retain the previous mode separations and image-width-normalized residuals; the lower panels add normalization by the ordinary landmark radius. Inputs were obtained from the preceding contribution experiment. The saved connections are not a proof of completeness or uniqueness, and the normalized residual does not fit relative rotation or magnification.

The browser changes select the archived CPU engine and all manuscript sampling settings together. The revised manuscript remains a single main.tex and contains Introduction, Methods and Results only. The workspace review directory retains prose audits, application regression outputs, final diffs and PDF checks. The combined analysis archive also contains the preceding contribution and tensor-interface calculations in their own directories. No software publication or DOI registration was performed.
