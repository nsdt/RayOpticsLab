from pathlib import Path
import json,math,hashlib,csv
R=Path(__file__).resolve().parents[1]
d=json.loads((R/'configs/landmark-input.json').read_text(encoding='utf8'))
def metric(o,e):
 m=len(o); assert m==len(e)>1
 centroid=[sum(p[k] for p in o)/m for k in range(2)]
 radius=math.sqrt(sum(sum((p[k]-centroid[k])**2 for k in range(2)) for p in o)/m)
 if radius<=0:raise ValueError('Ordinary landmark radius must be positive.')
 delta=[[b[k]-a[k] for k in range(2)] for a,b in zip(o,e)]
 shift=[sum(v[k] for v in delta)/m for k in range(2)]
 residual=math.sqrt(sum(sum((v[k]-shift[k])**2 for k in range(2)) for v in delta)/m)
 return radius,residual,residual/radius
records=[];checks=[]
for r in d['records']:
 point=lambda mode,label:next(p['pixel'] for p in r['points'] if p['mode']==mode and p['label']==label)
 o=[point(0,l) for l in ['U','D','L','R']];e=[point(1,l) for l in ['U','D','L','R']]
 radius,residual,ratio=metric(o,e)
 assert abs(residual*100/384-r['translationResidualPercent'])<1e-12
 pairvar=lambda a:sum(sum((p[k]-q[k])**2 for k in range(2)) for p in a for q in a)/(2*len(a)**2)
 delta=[[b[k]-a[k] for k in range(2)] for a,b in zip(o,e)]
 assert abs(math.sqrt(pairvar(delta)/pairvar(o))-ratio)<1e-14
 transform=lambda points,shift:[[3*(math.cos(.4)*x-math.sin(.4)*y)+shift[0],3*(math.sin(.4)*x+math.cos(.4)*y)+shift[1]] for x,y in points]
 assert abs(metric(transform(o,[2,-3]),transform(e,[-1,4]))[2]-ratio)<1e-14
 records.append({'group':r['group'],'value':r['value'],'ordinaryRadiusPixels':radius,'ordinaryRadiusFraction':radius/384,'translationResidualPixels':residual,'translationResidualPercent':residual*100/384,'normalizedTranslationResidual':ratio,'separations':r['separations']})
try:metric([[0,0],[0,0]],[[1,0],[1,0]])
except ValueError:pass
else:raise AssertionError('Zero radius accepted')
assert len(records)==15
out={'definition':'RMS translation residual divided by the RMS radius of the ordinary landmark positions about their centroid, evaluated separately at each parameter value.','sourceSHA256':hashlib.sha256((R/'configs/landmark-input.json').read_bytes()).hexdigest(),'landmarkCount':120,'records':records,'checks':{'retainedResidualAgreement':True,'independentPairwiseVarianceAgreement':True,'jointScaleAndRotationAndSeparateTranslationInvariance':True,'zeroRadiusRejected':True}}
(R/'data/normalized-landmarks.json').write_text(json.dumps(out,indent=2),encoding='utf8')
with (R/'data/normalized-landmarks.csv').open('w',encoding='utf8',newline='') as f:
 keys=[k for k in records[0] if k!='separations'];w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows({k:r[k] for k in keys} for r in records)
print(json.dumps([{k:v for k,v in r.items() if k!='separations'} for r in records],indent=2))