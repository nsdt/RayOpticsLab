from pathlib import Path
import json,shutil
import bootstrap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];P=R.parent/'manuscript';F=R/'figures'
d=json.loads((R/'data/normalized-landmarks.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':9,'axes.titlesize':10,'legend.fontsize':9,'pdf.fonttype':42})
fig,axes=plt.subplots(2,3,figsize=(7.3,5.1),sharex='col',sharey='row')
for col,group in enumerate(['reciprocal','quadratic','heliconical']):
 rows=[r for r in d['records'] if r['group']==group];x=[r['value'] for r in rows]
 for mark,color,marker in zip(['U','D','L','R'],['#0072b2','#d55e00','#008c64','#853c99'],['o','D','s','h']):
  axes[0,col].plot(x,[r['separations'][mark] for r in rows],color=color,marker=marker,ms=4,lw=1.2,label=mark)
 axes[0,col].plot(x,[r['translationResidualPercent'] for r in rows],'k--',marker='x',lw=1.2,ms=4,label='Translation residual')
 axes[1,col].plot(x,[r['normalizedTranslationResidual'] for r in rows],'k--',marker='x',lw=1.2,ms=4)
 for row in [0,1]:
  ax=axes[row,col];ax.set_title('('+chr(97+row*3+col)+')',loc='left');ax.grid(alpha=.2)
 axes[0,col].set_ylim(0,16);axes[1,col].set_ylim(0,.24)
 axes[1,col].set_xlabel(r'$\omega$' if group=='heliconical' else '$g$')
 axes[1,col].set_yticks([0,.05,.1,.15,.2])
 axes[1,col].set_xticks([0,1,2.5,4,6] if group=='heliconical' else [0,.1,.2,.3,.4])
axes[0,0].set_ylabel('Displacement / image width (%)')
axes[1,0].set_ylabel(r'Normalized residual $\widehat{r}_{\mathrm{tr}}$')
fig.legend(*axes[0,0].get_legend_handles_labels(),loc='lower center',ncol=5,frameon=False,bbox_to_anchor=(.53,.005))
fig.subplots_adjust(left=.1,right=.99,top=.95,bottom=.13,hspace=.25,wspace=.15)
for ext in ['pdf','png']:
 file=F/('quantitative-landmarks.'+ext);fig.savefig(file,dpi=200)
 if (P/'figures').is_dir():shutil.copy2(file,P/'figures'/file.name)
plt.close(fig);print('Figure 18 generated from 15 normalized landmark settings.')