# Numerical records accompanying the manuscript revision of 14 November 2026

The manuscript is organized around parameter-dependent images and browser access.
No numerical inputs, calculations, results, or engine files were changed in this
revision. Detailed validation plots and timing tables remain in this archive even
where they are no longer reproduced in the article or supplementary document.

## Contents

- contribution/: landmark connections, positive-dielectric interfaces, incoherent
  slab series, internal mode-conversion assessment, and CPU timing records.
- interfaces/: independent Maxwell checks for indefinite and transformation
  tensors, and exit-state decomposition of the physical image changes.
- normalization/: image-size normalization of the retained 120 landmark connections.

Each directory has its own README, requirements, source hashes, and commands.
Run the contribution calculations first, interfaces second, and normalization last.
The supplied normalization input is the original landmark record; to normalize a
new calculation, copy contribution/data/landmark-sweep.json to
normalization/configs/landmark-input.json before running its scripts.
The browser image button regenerates the 75 monochromatic and 4 spectral camera
configurations. This archive contains the additional analyses, not another copy
of all camera image arrays. Original propagation and image-sensitivity records
remain with the original camera-calculation archives in the software workspace.

## Figure numbers

Historical figure numbers inside the unchanged numerical scripts are mapped in
MANUSCRIPT_MAP.json. Historical Figure 18 now corresponds to article Figure 5 and
supplemental Figure S16. Historical Figure 19 is article Figure 6. Historical
Figure 20 (mode conversion) and the full validation/timing tables are retained as
numerical records; their summaries are in supplemental Section S5.

CPU timing records concern 144 camera directions on the recorded machine and
runtime. They do not measure full-frame GPU acceleration or browser responsiveness.
All original non-documentation files in this archive are byte-identical to the
preceding version. No DOI or public release is created by this packaging step.
